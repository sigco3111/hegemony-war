import {
  Duos,
  GameMode,
  GameType,
  HumansVsNations,
  maps,
  MessageType,
  PublicGameModifiers,
  Quads,
  Team,
  Trios,
} from "@openfront/engine-api/game/GameTypes";
import { GameConfig } from "@openfront/engine-api/Schemas";
import { DoomsdayClockSpeed } from "@openfront/engine-lib/game/DoomsdayClock";
import { stripVersionPrefix } from "@openfront/shared/ServerList";
import IntlMessageFormat from "intl-messageformat";
import { ClientEnv } from "./ClientEnv";
import type { LangSelector } from "./LangSelector";
import { pagePin } from "./PagePin";
import { Platform } from "./Platform";

export const TUTORIAL_VIDEO_URL = "https://www.youtube.com/embed/7J5zwb_s_Cg";

// The desktop shell cannot embed YouTube inside Electron, so it bundles the
// same tutorial and serves it under a reserved prefix of its app:// scheme
// (see openfront-desktop's protocol.ts, which pins this path with a test).
// Only meaningful when Platform.isElectron; on the web this path does not
// exist.
export const DESKTOP_TUTORIAL_VIDEO_URL = "/__tutorial/tutorial.webm";

export function normaliseMapKey(mapName: string): string {
  // Asset dirs / translation keys are the map id lowercased. For most maps
  // stripping spaces from the display name gives the same string, but not for
  // the tourney maps (e.g. "Tourney 2 Teams" lives in maps/tourney1/).
  const id = maps.find((m) => m.type === mapName)?.id;
  return (id ?? mapName).toLowerCase().replace(/[\s.]+/g, "");
}

/**
 * The map key desktop rich presence carries.
 *
 * Steam's localization file composes `#Map_<key>` and resolves it in the
 * *viewing* user's language, so presence has to send the normalised id -- the
 * same key `map.<id>` uses in our own translations, which keeps the two from
 * drifting apart -- rather than the display name, which would compose a token
 * that does not exist. Steam hides the entire status line when a token fails
 * to resolve, so getting this wrong is a total failure rather than a partial
 * one. Absent stays absent.
 */
export function presenceMapKey(
  gameMap: string | undefined,
): string | undefined {
  return gameMap === undefined ? undefined : normaliseMapKey(gameMap);
}

export function getMapName(mapName: string | undefined): string | null {
  if (!mapName) return null;
  const translationKey =
    maps.find((m) => m.type === mapName)?.translationKey ??
    `map.${normaliseMapKey(mapName)}`;
  return translateText(translationKey);
}

const TEAM_PRESET_SIZES = { [Duos]: 2, [Trios]: 3, [Quads]: 4 } as const;
const TEAM_PRESET_BY_SIZE: Record<number, string> = {
  2: Duos,
  3: Trios,
  4: Quads,
};

function presetTeamsLabel(
  preset: string,
  teamCount: number,
  playersPerTeam: number,
): string {
  return translateText("mode_selector.teams_preset", {
    teams: translateText("mode_selector.teams_of", {
      teamCount,
      playersPerTeam,
    }),
    preset: translateText(`detailed_view.layout_${preset.toLowerCase()}`),
  });
}

/**
 * Display label for a lobby's game mode, e.g. "Free for All",
 * "Trios (10 teams of 3)" or "5 teams of 20". A team count that splits the
 * lobby evenly into teams of 2-4 is named like the matching preset; an uneven
 * split shows only the team count.
 */
export function getGameModeLabel(gameConfig: GameConfig): string {
  const { gameMode, gameType, nations, playerTeams, maxPlayers } = gameConfig;

  if (gameMode !== GameMode.Team) {
    return translateText("game_mode.ffa");
  }

  if (playerTeams === HumansVsNations) {
    // Only public HvN on default nations matches the nation count to the humans.
    return maxPlayers && gameType === GameType.Public && nations === "default"
      ? translateText("public_lobby.teams_hvn_detailed", { num: maxPlayers })
      : translateText("public_lobby.teams_hvn");
  }

  if (playerTeams === Duos || playerTeams === Trios || playerTeams === Quads) {
    const playersPerTeam = TEAM_PRESET_SIZES[playerTeams];
    const teamCount = Math.floor((maxPlayers ?? 0) / playersPerTeam);
    return teamCount > 0
      ? presetTeamsLabel(playerTeams, teamCount, playersPerTeam)
      : translateText(`host_modal.teams_${playerTeams}`);
  }

  if (playerTeams === undefined || playerTeams <= 0) {
    return translateText("mode_selector.teams_title");
  }
  const players = maxPlayers ?? 0;
  if (players <= 0 || players % playerTeams !== 0) {
    return translateText("mode_selector.teams_count", {
      teamCount: playerTeams,
    });
  }
  const playersPerTeam = players / playerTeams;
  const preset = TEAM_PRESET_BY_SIZE[playersPerTeam];
  return preset !== undefined
    ? presetTeamsLabel(preset, playerTeams, playersPerTeam)
    : translateText("mode_selector.teams_of", {
        teamCount: playerTeams,
        playersPerTeam,
      });
}

export interface ModifierInfo {
  /** Translation key for detailed label (e.g. "game_settings.random_spawn") */
  labelKey: string;
  /** Translation key for badge/short label (e.g. "public_game_modifier.random_spawn") */
  badgeKey: string;
  /** Parameters to pass to translateText for the badge key */
  badgeParams?: Record<string, string | number>;
  /** The raw value if applicable (e.g. startingGold amount) */
  value?: number;
  /** Pre-formatted display string (used instead of renderNumber when provided) */
  formattedValue?: string;
}

/**
 * Returns structured modifier info for both detailed config display and badges.
 */
export function getActiveModifiers(
  modifiers: PublicGameModifiers | undefined,
  doomsdayClockSpeed?: DoomsdayClockSpeed,
): ModifierInfo[] {
  if (!modifiers) return [];
  const result: ModifierInfo[] = [];
  if (modifiers.isRandomSpawn) {
    result.push({
      labelKey: "game_settings.random_spawn",
      badgeKey: "public_game_modifier.random_spawn",
    });
  }
  if (modifiers.isCompact) {
    result.push({
      labelKey: "game_settings.compact_map",
      badgeKey: "public_game_modifier.compact_map",
    });
  }
  if (modifiers.isCrowded) {
    result.push({
      labelKey: "host_modal.crowded",
      badgeKey: "public_game_modifier.crowded",
    });
  }
  if (modifiers.isHardNations) {
    result.push({
      labelKey: "host_modal.hard_nations",
      badgeKey: "public_game_modifier.hard_nations",
    });
  }
  if (modifiers.startingGold) {
    const millions = parseFloat(
      (modifiers.startingGold / 1_000_000).toPrecision(12),
    );
    result.push({
      labelKey: "public_game_modifier.starting_gold_label",
      badgeKey: "public_game_modifier.starting_gold",
      badgeParams: {
        amount: millions,
      },
      value: modifiers.startingGold,
      formattedValue: `${millions}M`,
    });
  }
  if (modifiers.goldMultiplier) {
    result.push({
      labelKey: "game_settings.gold_multiplier",
      badgeKey: "public_game_modifier.gold_multiplier",
      badgeParams: {
        amount: modifiers.goldMultiplier,
      },
      value: modifiers.goldMultiplier,
      formattedValue: `x${modifiers.goldMultiplier}`,
    });
  }
  if (modifiers.isAlliancesDisabled) {
    result.push({
      labelKey: "public_game_modifier.disable_alliances_label",
      badgeKey: "public_game_modifier.disable_alliances",
      formattedValue: translateText("common.disabled"),
    });
  }
  if (modifiers.isPortsDisabled) {
    result.push({
      labelKey: "public_game_modifier.ports_disabled_label",
      badgeKey: "public_game_modifier.ports_disabled",
    });
  }
  if (modifiers.isNukesDisabled) {
    result.push({
      labelKey: "public_game_modifier.nukes_disabled_label",
      badgeKey: "public_game_modifier.nukes_disabled",
    });
  }
  if (modifiers.isSAMsDisabled) {
    result.push({
      labelKey: "public_game_modifier.sams_disabled_label",
      badgeKey: "public_game_modifier.sams_disabled",
    });
  }
  if (modifiers.isPeaceTime) {
    result.push({
      labelKey: "public_game_modifier.peace_time_label",
      badgeKey: "public_game_modifier.peace_time",
    });
  }
  if (modifiers.isWaterNukes) {
    result.push({
      labelKey: "game_settings.water_nukes",
      badgeKey: "public_game_modifier.water_nukes",
    });
  }
  if (modifiers.isDoomsdayClock) {
    const info: ModifierInfo = {
      labelKey: "game_settings.doomsday_clock",
      badgeKey: "public_game_modifier.doomsday_clock",
    };
    // Name the preset when we know it; older payloads / non-rotation lobbies
    // may not carry a speed, so keep the plain badge as a fallback.
    if (doomsdayClockSpeed !== undefined) {
      info.badgeKey = "public_game_modifier.doomsday_clock_with_speed";
      info.badgeParams = {
        speed: translateText(`doomsday_clock_speed.${doomsdayClockSpeed}`),
      };
    }
    result.push(info);
  }
  return result;
}

/**
 * Returns an array of translated modifier labels for badge display.
 */
export function getModifierLabels(
  modifiers: PublicGameModifiers | undefined,
  doomsdayClockSpeed?: DoomsdayClockSpeed,
): string[] {
  return getActiveModifiers(modifiers, doomsdayClockSpeed).map((m) =>
    translateText(m.badgeKey, m.badgeParams),
  );
}

export function renderDuration(totalSeconds: number): string {
  // Floor once so fractional inputs don't leak through to the seconds
  // component (e.g. `0.5` → `"0.5s"`).
  const whole = Math.floor(totalSeconds);
  if (whole <= 0) return `0${translateText("common.duration_second_short")}`;
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const seconds = whole % 60;
  // Build largest-first, dropping trailing-zero components so 3600s reads
  // as "1h" rather than "1h 0min 0s", and 60s as "1min" rather than
  // "1min 0s". Sub-minute durations still surface seconds.
  const parts: string[] = [];
  if (hours > 0)
    parts.push(`${hours}${translateText("common.duration_hour_short")}`);
  if (minutes > 0)
    parts.push(`${minutes}${translateText("common.duration_minute_short")}`);
  if (seconds > 0 || parts.length === 0)
    parts.push(`${seconds}${translateText("common.duration_second_short")}`);
  return parts.join(" ");
}

export async function copyToClipboard(
  text: string,
  onSuccess?: () => void,
  onReset?: () => void,
  timeout = 2000,
): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
    if (onSuccess) onSuccess();
    if (onReset) {
      setTimeout(() => {
        onReset();
      }, timeout);
    }
  } catch (err) {
    console.warn("Failed to copy to clipboard", err);
    throw err;
  }
}

export function formatPercentage(value: number): string {
  const perc = value * 100;
  if (Number.isNaN(perc)) return "0%";
  return perc.toFixed(1) + "%";
}

/**
 * Formats a keyboard key code for user-friendly display.
 * Handles empty values, spaces, and normalizes key codes like "Digit1" and "KeyA".
 *
 * @param value - The key code to format (e.g., "Digit1", "KeyA", "Space")
 * @returns The formatted key for display (e.g., "1", "A", "Space")
 *
 * @example
 * formatKeyForDisplay("Digit5") // returns "5"
 * formatKeyForDisplay("KeyA") // returns "A"
 * formatKeyForDisplay("Space") // returns "Space"
 * formatKeyForDisplay(" ") // returns "Space"
 * formatKeyForDisplay("ArrowUp") // returns "Arrowup"
 * formatKeyForDisplay("") // returns ""
 */
export function formatKeyForDisplay(value: string): string {
  // Handle empty string
  if (!value) return "";

  // Handle Shift+ prefix: format as "Shift+X"
  if (value.startsWith("Shift+")) {
    return "Shift+" + formatKeyForDisplay(value.slice(6));
  }

  // Handle space character or "Space" key
  if (value === " " || value === "Space") return "Space";

  // Handle DigitN pattern (e.g., "Digit1" -> "1")
  if (/^Digit\d$/.test(value)) {
    return value.replace("Digit", "");
  }

  // Handle KeyX pattern (e.g., "KeyA" -> "A")
  if (/^Key[A-Z]$/.test(value)) {
    return value.replace("Key", "");
  }

  // Fallback: capitalize first letter
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export function createCanvas(): HTMLCanvasElement {
  const canvas = document.createElement("canvas");

  // Set canvas style to fill the screen
  canvas.style.position = "fixed";
  canvas.style.left = "0";
  canvas.style.top = "0";
  canvas.style.width = "100%";
  canvas.style.height = "100%";
  canvas.style.touchAction = "none";

  return canvas;
}
/**
 * A polyfill for crypto.randomUUID that provides fallback implementations
 * for older browsers, particularly Safari versions < 15.4
 */
export function generateCryptoRandomUUID(): string {
  // Type guard to check if randomUUID is available
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }

  // Fallback using crypto.getRandomValues
  if (typeof crypto !== "undefined" && "getRandomValues" in crypto) {
    return (([1e7] as any) + -1e3 + -4e3 + -8e3 + -1e11).replace(
      /[018]/g,
      (c: number): string =>
        (
          c ^
          (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
        ).toString(16),
    );
  }

  // Last resort fallback using Math.random
  // Note: This is less cryptographically secure but ensures functionality
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
    /[xy]/g,
    (c: string): string => {
      const r: number = (Math.random() * 16) | 0;
      const v: number = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    },
  );
}

export function formatDebugTranslation(
  key: string,
  params: Record<string, string | number>,
): string {
  const entries = Object.entries(params);
  if (entries.length === 0) return key;
  const serializedParams = entries
    .map(([paramKey, value]) => `${paramKey}=${String(value)}`)
    .join(",");
  return `${key}::${serializedParams}`;
}

const EMPTY_TRANSLATION_PARAMS: Record<string, string | number> = {};

function getCachedLangSelector(): LangSelector | null {
  const self = translateText as any;
  const cached = self.langSelector as LangSelector | null | undefined;
  if (cached && cached.isConnected) return cached;

  // A lit update is scheduled on a microtask, so a component can render once
  // more after its environment has gone -- which in tests means `document` is
  // no longer defined by the time this runs. Returning null makes
  // translateText fall back to the key instead of throwing an unhandled
  // rejection that fails the whole run.
  if (typeof document === "undefined") {
    self.langSelector = null;
    return null;
  }

  const found = document.querySelector("lang-selector") as LangSelector | null;
  self.langSelector = found ?? null;
  return found;
}

/** Language codes whose script reads right-to-left (resources/lang/metadata.json). */
const RTL_LANGUAGES = new Set(["ar", "fa", "he"]);

/**
 * True when the given language renders right-to-left. Defaults to the
 * currently selected UI language, so callers can simply write `isRTL()`.
 */
export const isRTL = (lang?: string): boolean => {
  const code = (lang ?? getCachedLangSelector()?.currentLang ?? "en").split(
    "-",
  )[0];
  return RTL_LANGUAGES.has(code);
};

/**
 * Value for the HTML `dir` attribute matching the current UI language.
 * Apply it to containers whose text comes from translateText() so Persian,
 * Arabic and Hebrew render right-to-left with correct mixed-content ordering.
 */
export const textDirection = (): "rtl" | "ltr" => (isRTL() ? "rtl" : "ltr");

export const translateText = (
  key: string,
  params?: Record<string, string | number>,
): string => {
  const self = translateText as any;
  self.formatterCache ??= new Map();
  self.lastLang ??= null;

  const langSelector = getCachedLangSelector();
  if (!langSelector) {
    return key;
  }

  const resolvedParams = params ?? EMPTY_TRANSLATION_PARAMS;

  if (langSelector.currentLang === "debug") {
    return formatDebugTranslation(key, resolvedParams);
  }

  const translations = langSelector.translations;
  const defaultTranslations = langSelector.defaultTranslations;
  if (!translations && !defaultTranslations) return key;

  if (self.lastLang !== langSelector.currentLang) {
    self.formatterCache.clear();
    self.lastLang = langSelector.currentLang;
  }

  let message = translations?.[key];
  const hasPrimaryTranslation = message !== undefined;

  message ??= defaultTranslations?.[key];

  if (message === undefined) return key;

  // Fast path: no params and no ICU placeholders.
  if (
    resolvedParams === EMPTY_TRANSLATION_PARAMS &&
    message.indexOf("{") === -1
  ) {
    return message;
  }

  try {
    const locale =
      !hasPrimaryTranslation && langSelector.currentLang !== "en"
        ? "en"
        : langSelector.currentLang;
    const cacheKey = `${key}:${locale}:${message}`;
    let formatter = self.formatterCache.get(cacheKey);

    if (!formatter) {
      formatter = new IntlMessageFormat(message, locale);
      self.formatterCache.set(cacheKey, formatter);
    }

    return formatter.format(resolvedParams) as string;
  } catch (e) {
    console.warn("ICU format error", e);
    return message;
  }
};

/**
 * Whether `key` is translated in the player's own language, rather than only
 * in the English that translateText falls back to.
 */
export const hasOwnTranslation = (key: string): boolean =>
  getCachedLangSelector()?.translations?.[key] !== undefined;

export interface HasClanTag {
  clanTag?: string | null | (() => string | null);
}

type TopClans = {
  topTag: string | null;
  topCount: number;
  secondTag: string | null;
  secondCount: number;
  thirdCount: number;
};

function getTopClans(players: readonly HasClanTag[]): TopClans {
  const counts = new Map<string, number>();
  for (const p of players) {
    const tag = typeof p.clanTag === "function" ? p.clanTag() : p.clanTag;
    if (tag && tag.trim().length > 0) {
      counts.set(tag, (counts.get(tag) ?? 0) + 1);
    }
  }
  let topTag: string | null = null,
    topCount = 0;
  let secondTag: string | null = null,
    secondCount = 0;
  let thirdCount = 0;

  for (const [tag, count] of counts) {
    if (count > topCount) {
      thirdCount = secondCount;
      secondTag = topTag;
      secondCount = topCount;
      topTag = tag;
      topCount = count;
    } else if (count > secondCount) {
      thirdCount = secondCount;
      secondTag = tag;
      secondCount = count;
    } else if (count > thirdCount) {
      thirdCount = count;
    }
  }
  return { topTag, topCount, secondTag, secondCount, thirdCount };
}

export function resolveTeamClanTag(
  players: Iterable<HasClanTag>,
): string | null {
  const list = Array.isArray(players) ? players : Array.from(players);
  const n = list.length;
  if (n === 0) return null;

  const { topTag, topCount, secondTag, secondCount, thirdCount } =
    getTopClans(list);

  if (topTag && topCount > n / 2) {
    return topTag;
  }
  if (
    topTag &&
    secondTag &&
    secondCount > thirdCount &&
    (topCount + secondCount) / n >= 0.7 &&
    secondCount / n >= 0.3
  ) {
    return [topTag, secondTag].sort().join(" / ");
  }
  return null;
}

export function getTranslatedPlayerTeamLabel(
  team: Team | null,
  clanTag?: string | null,
): string {
  if (!team) return "";
  if (clanTag) {
    return `[${clanTag}]`;
  }
  const translationKey = `team_colors.${team.toLowerCase()}`;
  const translated = translateText(translationKey);
  return translated === translationKey ? team : translated;
}

export const severityColors: Record<string, string> = {
  fail: "text-red-400",
  warn: "text-yellow-400",
  success: "text-green-400",
  info: "text-gray-200",
  blue: "text-blue-400",
  white: "text-white",
};

/**
 * Maps a message type to the Tailwind text-color class of its severity.
 */
export function getMessageTypeClasses(type: MessageType): string {
  switch (type) {
    case MessageType.SAM_HIT:
    case MessageType.CAPTURED_ENEMY_UNIT:
    case MessageType.CONQUERED_PLAYER:
    case MessageType.ALLIANCE_ACCEPTED:
      return severityColors["success"];
    case MessageType.ATTACK_FAILED:
    case MessageType.ALLIANCE_REJECTED:
    case MessageType.ALLIANCE_BROKEN:
    case MessageType.UNIT_DESTROYED:
    case MessageType.NUKE_DETONATED:
      return severityColors["fail"];
    case MessageType.ATTACK_CANCELLED:
    case MessageType.ATTACK_REQUEST:
    case MessageType.DONATION_SENT:
    case MessageType.DONATION_RECEIVED:
      return severityColors["blue"];
    case MessageType.MIRV_INBOUND:
    case MessageType.NUKE_INBOUND:
    case MessageType.HYDROGEN_BOMB_INBOUND:
    case MessageType.SAM_MISS:
    case MessageType.ALLIANCE_EXPIRED:
    case MessageType.NAVAL_INVASION_INBOUND:
    case MessageType.RENEW_ALLIANCE:
      return severityColors["warn"];
    case MessageType.CHAT:
    case MessageType.ALLIANCE_REQUEST:
      return severityColors["info"];
    default:
      console.warn(`Message type ${type} has no explicit color`);
      return severityColors["white"];
  }
}

export function getModifierKey(): string {
  return Platform.isMac ? "⌘" : "Ctrl";
}

export function getAltKey(): string {
  return Platform.isMac ? "⌥" : "Alt";
}

export function getGamesPlayed(): number {
  try {
    return parseInt(localStorage.getItem("gamesPlayed") ?? "0", 10) || 0;
  } catch (error) {
    console.warn("Failed to read games played from localStorage:", error);
    return 0;
  }
}

export function incrementGamesPlayed(): void {
  try {
    localStorage.setItem("gamesPlayed", (getGamesPlayed() + 1).toString());
  } catch (error) {
    console.warn("Failed to increment games played in localStorage:", error);
  }
}

export function isInIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch (e) {
    // If we can't access window.top due to cross-origin restrictions,
    // we're definitely in an iframe
    return true;
  }
}

export async function getSvgAspectRatio(src: string): Promise<number | null> {
  const self = getSvgAspectRatio as any;
  self.svgAspectRatioCache ??= new Map();

  const cached = self.svgAspectRatioCache.get(src);
  if (cached !== undefined) return cached;

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(src, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!resp.ok) throw new Error(`Fetch failed: ${resp.status}`);
    const text = await resp.text();

    // Try parse viewBox
    const vbMatch = text.match(/viewBox="([^"]+)"/i);
    if (vbMatch) {
      const parts = vbMatch[1]
        .trim()
        .split(/[\s,]+/)
        .map(Number);
      if (parts.length === 4 && parts.every((n) => !Number.isNaN(n))) {
        const [, , vbW, vbH] = parts;
        if (vbW > 0 && vbH > 0) {
          const ratio = vbW / vbH;
          self.svgAspectRatioCache.set(src, ratio);
          return ratio;
        }
      }
    }

    // Fallback to width/height attributes (may be with units; strip px)
    const widthMatch = text.match(/<svg[^>]*\swidth="([^"]+)"/i);
    const heightMatch = text.match(/<svg[^>]*\sheight="([^"]+)"/i);
    if (widthMatch && heightMatch) {
      const parseNum = (s: string) => Number(s.replace(/[^0-9.]/g, ""));
      const w = parseNum(widthMatch[1]);
      const h = parseNum(heightMatch[1]);
      if (w > 0 && h > 0) {
        const ratio = w / h;
        self.svgAspectRatioCache.set(src, ratio);
        return ratio;
      }
    }
    // Not an SVG or no usable metadata
  } catch (e) {
    // fetch may fail due to CORS or non-SVG..
  }

  const imgRatio = await new Promise<number | null>((resolve) => {
    const img = new Image();
    img.onload = () => {
      if (img.naturalWidth > 0 && img.naturalHeight > 0) {
        resolve(img.naturalWidth / img.naturalHeight);
      } else {
        resolve(null);
      }
    };
    img.onerror = () => resolve(null);
    img.src = src;
  });

  if (imgRatio !== null) {
    self.svgAspectRatioCache.set(src, imgRatio);
    return imgRatio;
  }

  return null;
}

export function getDiscordAvatarUrl(user: {
  id: string;
  avatar: string | null;
  discriminator?: string;
}): string | null {
  if (user.avatar) {
    // - id is a Discord numeric string
    // - avatar is a hash, optionally prefixed with "a_" for animated avatars
    const validId = /^\d+$/.test(user.id);
    const validAvatar =
      /^[a-f0-9]+$/.test(user.avatar) || /^a_[a-f0-9]+$/.test(user.avatar);

    if (validId && validAvatar) {
      const extension = user.avatar.startsWith("a_") ? "gif" : "png";
      return `https://cdn.discordapp.com/avatars/${encodeURIComponent(user.id)}/${encodeURIComponent(user.avatar)}.${extension}?size=64`;
    }
  }

  if (user.discriminator !== undefined) {
    const idx = Number(user.discriminator) % 5;
    return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
  }

  return null;
}
export function calculateServerTimeOffset(
  serverTimeMs: number,
  localNowMs: number = Date.now(),
): number {
  return serverTimeMs - localNowMs;
}

export function getServerNow(
  serverTimeOffsetMs: number,
  localNowMs: number = Date.now(),
): number {
  return localNowMs + serverTimeOffsetMs;
}

export function showToast(
  message: string,
  color: "red" | "green",
  duration = 3500,
): void {
  window.dispatchEvent(
    new CustomEvent("show-message", {
      detail: { message, color, duration },
    }),
  );
}

const RELOAD_TOAST_KEY = "reloadToast";

// Holds the translated text, not the key: on the far side of the reload the
// language files may not have landed yet and translateText would echo the key.
export function showToastAfterReload(message: string): void {
  try {
    sessionStorage.setItem(RELOAD_TOAST_KEY, message);
  } catch {
    // sessionStorage unavailable: the reload still happens, just silently.
  }
}

export function flushReloadToast(): void {
  let message: string | null;
  try {
    message = sessionStorage.getItem(RELOAD_TOAST_KEY);
    sessionStorage.removeItem(RELOAD_TOAST_KEY);
  } catch {
    return;
  }
  if (message) showToast(message, "green");
}

export function getSecondsUntilServerTimestamp(
  targetServerTimestampMs: number,
  serverTimeOffsetMs: number,
  localNowMs: number = Date.now(),
): number {
  return Math.max(
    0,
    Math.floor(
      (targetServerTimestampMs - getServerNow(serverTimeOffsetMs, localNowMs)) /
        1000,
    ),
  );
}

/**
 * Reload to pick up a newly deployed version. The app shell is served with a
 * shared-cache TTL (RenderHtml.ts), so a plain reload can hand back the same
 * stale HTML — with the old gitCommit baked in — for minutes after a deploy,
 * and a version check that reloads on mismatch would loop. A unique query
 * string misses the shared cache, so the origin renders the current shell.
 *
 * On a deployment host (the document landed there for a cross-host game, or
 * via a stale bookmark) a same-origin reload re-fetches that SAME
 * deployment's shell — for a drained or outdated deployment that can never
 * help, and the drain prompt would loop forever. The apex serves the active
 * deployment's shell, so go there instead, keeping the path (letter routing
 * re-resolves a /game/<id>) minus the origin-specific worker prefix.
 */
export function reloadForUpdate(): void {
  const url = new URL(window.location.href);
  const siteHost = ClientEnv.siteHost();
  if (siteHost !== undefined && url.host !== siteHost) {
    url.protocol = "https:";
    url.host = siteHost;
  }
  // Both prefixes encode what this reload exists to leave behind, whichever
  // host answers it. `/v/<commit>/` is immutable by design (multi-server
  // v2): it pins the bundle, so reloading it as-is re-serves the very
  // version being updated away from, forever, cache-buster or not. And
  // `/w<n>/` was resolved against the old worker count, which a new version
  // may have changed — letter routing picks the worker again on the way
  // back in. apexPathFor drops exactly these two, in either order.
  url.pathname = apexPathFor(url.pathname);
  url.searchParams.set("v", Date.now().toString(36));
  window.location.replace(url.toString());
}

/**
 * The path to ask the apex for when re-entering through it. Both prefixes a
 * path can carry are specific to where the page came from, and the apex
 * re-resolves what they encoded: `/w<n>/` is one deployment's worker (letter
 * routing picks the worker again), and `/v/<commit>/` pins the version whose
 * staleness is the reason for going to the apex in the first place. Pure so
 * the rule is testable without booting Main.
 */
export function apexPathFor(pathname: string): string {
  const { path } = stripVersionPrefix(pathname);
  return path.replace(/^\/w\d+\//, "/");
}

/**
 * A same-origin path as THIS document should write it into its own history:
 * re-prefixed with the page's `/v/<commit>/` when it has one, unchanged
 * otherwise.
 *
 * History entries are not share links, and the two want opposite things. A
 * share link is version-free on purpose — the recipient should be routed by
 * whatever version the game's server runs when they open it. A history entry
 * is this tab's own URL: pressing F5 on it must reload THE BUNDLE THIS PAGE
 * IS RUNNING, and on a pinned page a version-free path would silently hand
 * the player `latest` instead, mid-game.
 *
 * Reads the pin captured at boot rather than the live pathname: the join
 * flow rewrites the address bar to the version-free share URL before this
 * ever runs in a game, and a version-free history entry is precisely what
 * this exists to avoid writing (PagePin.ts).
 */
export function currentPagePath(path: string): string {
  const commit = pagePin();
  return commit === null ? path : `/v/${commit}${path}`;
}

/**
 * Where "leave to the menu" navigations should land. On a deployment host
 * the local homepage may belong to a drained deployment whose public lobby
 * list is empty; the apex always fronts the active one. Same-host,
 * standalone deployments (no siteHost injected), dev, and desktop keep the
 * plain root.
 *
 * The plain root is also the right answer on a `/v/<commit>/` page, and for
 * the same reason: "/" is version-free, so a player leaving to the menu
 * lands on `latest` rather than back on the build they were leaving.
 */
export function homeHref(): string {
  const siteHost = ClientEnv.siteHost();
  if (siteHost !== undefined && window.location.host !== siteHost) {
    return `https://${siteHost}/`;
  }
  // Hegemony: the Pages build serves under a repo subpath, so "/" would
  // navigate off the site into a 404. Vite bakes the base path in at build
  // time (PAGES_BASE).
  if (ClientEnv.soloStatic()) return import.meta.env.BASE_URL;
  return "/";
}
