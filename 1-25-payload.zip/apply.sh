#!/bin/bash
# payload25: 후방 방어 위임 (개선6)
set -e
cp -r /tmp/payload/files/. .
