#!/bin/bash
set -e
cd "$GITHUB_WORKSPACE"
cp -r /tmp/payload/files/. .
bash /tmp/payload/rmlist.sh
# remove now-empty dirs
find resources/sounds proprietary -type d -empty -delete 2>/dev/null || true
rmdir resources/sounds proprietary 2>/dev/null || true
