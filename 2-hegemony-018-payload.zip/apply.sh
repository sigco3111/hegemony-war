#!/bin/bash
set -e
cd "$GITHUB_WORKSPACE"
cp -r /tmp/payload/files/. .
