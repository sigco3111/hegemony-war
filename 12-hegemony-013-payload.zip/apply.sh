#!/bin/bash
set -e
cd "$GITHUB_WORKSPACE"
cp -r /tmp/payload/files/. .
# Remove the 12 upstream workflows; only pages.yml (apply-payload) stays.
rm -f .github/workflows/cherry-pick-milestone.yml \
      .github/workflows/ci.yml \
      .github/workflows/claude-code-review.yml \
      .github/workflows/deploy.yml \
      .github/workflows/issue-lifecycle-cron.yml \
      .github/workflows/issue-lifecycle-events.yml \
      .github/workflows/pr-author.yml \
      .github/workflows/pr-close-on-label.yml \
      .github/workflows/pr-description.yml \
      .github/workflows/pr-gate.yml \
      .github/workflows/pr-stale.yml \
      .github/workflows/release.yml
