import {
  GameMode,
  GameType,
  type Team,
} from "@openfront/engine-api/game/GameTypes";
import { assetUrl } from "@openfront/shared/AssetUrls";
import type { EventBus } from "@openfront/shared/EventBus";
import { Colord } from "colord";
import { html, LitElement } from "lit";
import { customElement, property, query, state } from "lit/decorators.js";
import type { Controller } from "../../Controller";
import { Platform } from "../../Platform";
import { themeProvider } from "../../theme/ThemeProvider";
import { getTranslatedPlayerTeamLabel, translateText } from "../../Utils";
import type { GameView } from "../../view";
import { ImmunityBarVisibleEvent } from "./ImmunityTimer";
import { ToggleDelegationPanelEvent } from "./DelegationPanel";
import {
  ToggleWarPlanPanelEvent,
  WarPlanChangedEvent,
} from "../../WarPlan";
import { ToggleDiplomacyBoardEvent } from "./DiplomacyBoard";
import {
  DiplomacyOverlayStatusEvent,
  ToggleDiplomacyOverlayEvent,
} from "../../DiplomacyMarkers";
import { ToggleWarDashboardEvent } from "./WarDashboard";
import "./PlayerStats";
import type { PlayerStats } from "./PlayerStats";
import { SpawnBarVisibleEvent } from "./SpawnTimer";
import "./TeamStats";
import type { TeamStats } from "./TeamStats";
const playerStatsRegularIcon = assetUrl(
  "images/LeaderboardIconRegularWhite.svg",
);
const playerStatsSolidIcon = assetUrl("images/LeaderboardIconSolidWhite.svg");
const teamStatsRegularIcon = assetUrl("images/TeamIconRegularWhite.svg");
const teamStatsSolidIcon = assetUrl("images/TeamIconSolidWhite.svg");

@customElement("game-left-sidebar")
export class GameLeftSidebar extends LitElement implements Controller {
  @state()
  private isPlayerStatsShown = false;
  @state()
  private isTeamStatsShown = false;
  @state()
  private isVisible = false;
  @state()
  private isPlayerTeamLabelVisible = false;
  @state()
  private playerTeam: Team | null = null;
  @state()
  private spawnBarVisible = false;
  @state()
  private immunityBarVisible = false;
  @state()
  private planQueuedCount = 0;
  @state()
  private planExecuting = false;
  @state()
  private diplomacyOverlayOn = true;
  @state()
  private diplomacyOverlayAttackers = 0;

  private playerColor: Colord = new Colord("#FFFFFF");
  @property({ attribute: false }) public game: GameView | null = null;
  @property({ attribute: false }) public eventBus: EventBus | null = null;
  @query("player-stats") private playerStats?: PlayerStats;
  @query("team-stats") private teamStats?: TeamStats;
  private showPlayerStatsAfterSpawn = false;

  createRenderRoot() {
    return this;
  }

  private lastStatsRefreshMs = 0;

  init() {
    this.isVisible = true;
    // 렌더러 tick은 게임 업데이트 때만 돈다. 이어하기 직후 일시정지 상태에서는
    // 마지막 따라잡기 틱이 갱신 간격에 막혀 순위표가 낡은 채로 남으므로,
    // 일정 시간 갱신이 없으면 타이머로 한 번 더 갱신한다.
    setInterval(() => {
      if (this.game === null) return;
      if (performance.now() - this.lastStatsRefreshMs < 1500) return;
      this.lastStatsRefreshMs = performance.now();
      this.playerStats?.refresh();
      this.teamStats?.refresh();
    }, 1000);
    this.eventBus?.on(SpawnBarVisibleEvent, (e) => {
      this.spawnBarVisible = e.visible;
    });
    this.eventBus?.on(ImmunityBarVisibleEvent, (e) => {
      this.immunityBarVisible = e.visible;
    });
    // 개선 7: badge on the 작전 button mirrors the plan queue.
    this.planQueuedCount = 0;
    this.planExecuting = false;
    this.eventBus?.on(WarPlanChangedEvent, (e) => {
      this.planQueuedCount = e.queuedCount;
      this.planExecuting = e.executing;
    });
    // 개선 8: map overlay toggle state + attacker badge.
    this.eventBus?.on(DiplomacyOverlayStatusEvent, (e) => {
      this.diplomacyOverlayOn = e.visible;
      this.diplomacyOverlayAttackers = e.attackerCount;
    });
    if (this.isTeamGame) {
      this.isPlayerTeamLabelVisible = true;
    }
    // Make it visible by default on large screens
    if (Platform.isDesktopWidth) {
      this.showPlayerStatsAfterSpawn = true;
    }
  }

  getTickIntervalMs() {
    return 1000;
  }

  tick() {
    if (this.game === null) return;

    const team = this.game.myPlayer()?.team();
    if (this.playerTeam === null && team !== null && team !== undefined) {
      this.playerTeam = team;
      this.playerColor = themeProvider.current().teamColor(team);
    }

    if (this.showPlayerStatsAfterSpawn && !this.game.inSpawnPhase()) {
      this.showPlayerStatsAfterSpawn = false;
      this.isPlayerStatsShown = true;
    }

    if (!this.game.inSpawnPhase() && this.isPlayerTeamLabelVisible) {
      this.isPlayerTeamLabelVisible = false;
    }

    this.lastStatsRefreshMs = performance.now();
    this.playerStats?.refresh();
    this.teamStats?.refresh();
  }

  private get barOffset(): number {
    return (this.spawnBarVisible ? 7 : 0) + (this.immunityBarVisible ? 7 : 0);
  }

  private togglePlayerStats(): void {
    this.isPlayerStatsShown = !this.isPlayerStatsShown;
  }

  private toggleTeamStats(): void {
    this.isTeamStatsShown = !this.isTeamStatsShown;
  }

  // Hegemony: the war dashboard (전황) is a singleplayer-only panel.
  private get isSoloGame(): boolean {
    return (
      this.game?.config().gameConfig().gameType === GameType.Singleplayer
    );
  }

  private toggleWarDashboard(): void {
    // The solo overlays stack in the same spot: never show two at once.
    this.eventBus?.emit(new ToggleDiplomacyBoardEvent(false));
    this.eventBus?.emit(new ToggleDelegationPanelEvent(false));
    this.eventBus?.emit(new ToggleWarPlanPanelEvent(false));
    this.eventBus?.emit(new ToggleWarDashboardEvent());
  }

  private toggleDiplomacyBoard(): void {
    this.eventBus?.emit(new ToggleWarDashboardEvent(false));
    this.eventBus?.emit(new ToggleDelegationPanelEvent(false));
    this.eventBus?.emit(new ToggleWarPlanPanelEvent(false));
    this.eventBus?.emit(new ToggleDiplomacyBoardEvent());
  }

  // Hegemony 개선6: the rear-defense delegation (위임) panel.
  private toggleDelegationPanel(): void {
    this.eventBus?.emit(new ToggleWarDashboardEvent(false));
    this.eventBus?.emit(new ToggleDiplomacyBoardEvent(false));
    this.eventBus?.emit(new ToggleWarPlanPanelEvent(false));
    this.eventBus?.emit(new ToggleDelegationPanelEvent());
  }

  // Hegemony 개선8: map diplomacy/threat overlay (지도 표시). Not a
  // panel — toggling it never closes the other overlays.
  private toggleDiplomacyOverlay(): void {
    this.eventBus?.emit(new ToggleDiplomacyOverlayEvent());
  }

  // Hegemony 개선7: the pause operation plan (작전) panel.
  private toggleWarPlanPanel(): void {
    this.eventBus?.emit(new ToggleWarDashboardEvent(false));
    this.eventBus?.emit(new ToggleDiplomacyBoardEvent(false));
    this.eventBus?.emit(new ToggleDelegationPanelEvent(false));
    this.eventBus?.emit(new ToggleWarPlanPanelEvent());
  }

  private get isTeamGame(): boolean {
    return this.game?.config().gameConfig().gameMode === GameMode.Team;
  }

  render() {
    return html`
      <aside
        class=${`fixed top-0 left-0 z-900 flex flex-col max-h-[calc(100vh-80px)] overflow-y-auto p-2 bg-gray-800/92 backdrop-blur-sm shadow-xs rounded-br-lg ${this.isPlayerStatsShown || this.isTeamStatsShown ? "max-[400px]:w-full max-[400px]:rounded-none" : ""} transition-all duration-300 ease-out transform ${
          this.isVisible ? "translate-x-0" : "hidden"
        }`}
        style="margin-top: ${this.barOffset}px;"
      >
        <div class="flex flex-wrap items-center gap-4 max-[480px]:max-w-[132px] max-[480px]:gap-2 xl:gap-6 text-white">
          <div
            class="cursor-pointer p-0.5 bg-gray-700/50 hover:bg-gray-600 border rounded-md border-slate-500 transition-colors"
            @click=${this.togglePlayerStats}
            role="button"
            tabindex="0"
            @keydown=${(e: KeyboardEvent) => {
              if (e.key === "Enter" || e.key === " " || e.code === "Space") {
                e.preventDefault();
                this.togglePlayerStats();
              }
            }}
          >
            <img
              src=${this.isPlayerStatsShown
                ? playerStatsSolidIcon
                : playerStatsRegularIcon}
              alt=${translateText("help_modal.icon_alt_player_leaderboard") ||
              "Player Leaderboard Icon"}
              width="20"
              height="20"
            />
          </div>
          ${this.isSoloGame
            ? html`
                <div
                  class="cursor-pointer p-0.5 bg-gray-700/50 hover:bg-gray-600 border rounded-md border-slate-500 transition-colors"
                  @click=${this.toggleWarDashboard}
                  role="button"
                  tabindex="0"
                  title=${translateText("war_dashboard.title")}
                  @keydown=${(e: KeyboardEvent) => {
                    if (
                      e.key === "Enter" ||
                      e.key === " " ||
                      e.code === "Space"
                    ) {
                      e.preventDefault();
                      this.toggleWarDashboard();
                    }
                  }}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    aria-hidden="true"
                  >
                    <rect x="2" y="10" width="4" height="8" rx="1" fill="#fff" />
                    <rect x="8" y="6" width="4" height="12" rx="1" fill="#fff" />
                    <rect x="14" y="2" width="4" height="16" rx="1" fill="#fff" />
                  </svg>
                </div>
                <div
                  class="cursor-pointer p-0.5 bg-gray-700/50 hover:bg-gray-600 border rounded-md border-slate-500 transition-colors"
                  @click=${this.toggleDiplomacyBoard}
                  role="button"
                  tabindex="0"
                  title=${translateText("diplomacy_board.title")}
                  @keydown=${(e: KeyboardEvent) => {
                    if (
                      e.key === "Enter" ||
                      e.key === " " ||
                      e.code === "Space"
                    ) {
                      e.preventDefault();
                      this.toggleDiplomacyBoard();
                    }
                  }}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M7 11.5 3.5 8a2.5 2.5 0 0 1 3.5-3.5l3 3 3-3A2.5 2.5 0 0 1 16.5 8l-5.2 5.2a2.2 2.2 0 0 1-3.1 0L7 12"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      fill="none"
                    />
                    <path
                      d="M7 11.5 4.6 13.9M13 11.5l2.4 2.4"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linecap="round"
                    />
                  </svg>
                </div>
                <div
                  class="cursor-pointer p-0.5 bg-gray-700/50 hover:bg-gray-600 border rounded-md border-slate-500 transition-colors"
                  @click=${this.toggleDelegationPanel}
                  role="button"
                  tabindex="0"
                  title=${translateText("delegation_panel.title")}
                  @keydown=${(e: KeyboardEvent) => {
                    if (
                      e.key === "Enter" ||
                      e.key === " " ||
                      e.code === "Space"
                    ) {
                      e.preventDefault();
                      this.toggleDelegationPanel();
                    }
                  }}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M10 2 3.5 4.5v5c0 4 2.7 7.2 6.5 8.5 3.8-1.3 6.5-4.5 6.5-8.5v-5L10 2Z"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linejoin="round"
                      fill="none"
                    />
                    <path
                      d="M7 10l2 2 4-4.5"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      fill="none"
                    />
                  </svg>
                </div>
                <div
                  class="relative cursor-pointer p-0.5 bg-gray-700/50 hover:bg-gray-600 border rounded-md border-slate-500 transition-colors"
                  @click=${this.toggleWarPlanPanel}
                  role="button"
                  tabindex="0"
                  title=${translateText("war_plan.sidebar_title")}
                  @keydown=${(e: KeyboardEvent) => {
                    if (
                      e.key === "Enter" ||
                      e.key === " " ||
                      e.code === "Space"
                    ) {
                      e.preventDefault();
                      this.toggleWarPlanPanel();
                    }
                  }}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    aria-hidden="true"
                  >
                    <circle
                      cx="10"
                      cy="10"
                      r="6.2"
                      stroke="#fff"
                      stroke-width="1.6"
                      fill="none"
                    />
                    <circle cx="10" cy="10" r="1.6" fill="#fff" />
                    <path
                      d="M10 1.2v3M10 15.8v3M1.2 10h3M15.8 10h3"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linecap="round"
                    />
                  </svg>
                  ${this.planQueuedCount > 0
                    ? html`<span
                        class="absolute -top-1.5 -right-1.5 min-w-4 h-4 px-0.5 rounded-full ${this.planExecuting
                          ? "bg-emerald-500"
                          : "bg-sky-600"} text-white text-[10px] font-bold leading-4 text-center tabular-nums"
                      >
                        ${this.planQueuedCount}
                      </span>`
                    : null}
                </div>
                <div
                  class="relative cursor-pointer p-0.5 border rounded-md transition-colors ${this
                    .diplomacyOverlayOn
                    ? "bg-emerald-700/60 hover:bg-emerald-600/60 border-emerald-400"
                    : "bg-gray-700/50 hover:bg-gray-600 border-slate-500"}"
                  @click=${this.toggleDiplomacyOverlay}
                  role="button"
                  tabindex="0"
                  title=${translateText("diplomacy_overlay.sidebar_title")}
                  @keydown=${(e: KeyboardEvent) => {
                    if (
                      e.key === "Enter" ||
                      e.key === " " ||
                      e.code === "Space"
                    ) {
                      e.preventDefault();
                      this.toggleDiplomacyOverlay();
                    }
                  }}
                >
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    aria-hidden="true"
                  >
                    <path
                      d="M5 2.5v15"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linecap="round"
                    />
                    <path
                      d="M5 3.5h10l-2.75 3.5L15 10.5H5"
                      stroke="#fff"
                      stroke-width="1.6"
                      stroke-linejoin="round"
                      fill="none"
                    />
                  </svg>
                  ${this.diplomacyOverlayOn &&
                  this.diplomacyOverlayAttackers > 0
                    ? html`<span
                        class="absolute -top-1.5 -right-1.5 min-w-4 h-4 px-0.5 rounded-full bg-red-500 text-white text-[10px] font-bold leading-4 text-center tabular-nums"
                      >
                        ${this.diplomacyOverlayAttackers}
                      </span>`
                    : null}
                </div>
              `
            : null}
          ${this.isTeamGame
            ? html`
                <div
                  class="cursor-pointer p-0.5 bg-gray-700/50 hover:bg-gray-600 border rounded-md border-slate-500 transition-colors"
                  @click=${this.toggleTeamStats}
                  role="button"
                  tabindex="0"
                  @keydown=${(e: KeyboardEvent) => {
                    if (
                      e.key === "Enter" ||
                      e.key === " " ||
                      e.code === "Space"
                    ) {
                      e.preventDefault();
                      this.toggleTeamStats();
                    }
                  }}
                >
                  <img
                    src=${this.isTeamStatsShown
                      ? teamStatsSolidIcon
                      : teamStatsRegularIcon}
                    alt=${translateText(
                      "help_modal.icon_alt_team_leaderboard",
                    ) || "Team Leaderboard Icon"}
                    width="20"
                    height="20"
                  />
                </div>
              `
            : null}
          ${this.isPlayerStatsShown || this.isTeamStatsShown
            ? html`<span
                class="ml-auto text-[10px] text-slate-500 select-all leading-none self-start"
                title=${translateText("help_modal.game_id_tooltip")}
                >${this.game?.gameID() ?? ""}</span
              >`
            : null}
        </div>
        ${this.isPlayerTeamLabelVisible
          ? html`
              <div
                class="flex items-center w-full text-white mt-2"
                @contextmenu=${(e: Event) => e.preventDefault()}
              >
                ${translateText("help_modal.ui_your_team")}
                <span
                  style="--color: ${this.playerColor.toRgbString()}"
                  class="text-(--color)"
                >
                  &nbsp;${getTranslatedPlayerTeamLabel(
                    this.playerTeam,
                    this.game?.teamClanTag(this.playerTeam),
                  )}
                  &#10687;
                </span>
              </div>
            `
          : null}
        <div class="flex flex-col gap-2 min-w-0 w-full">
          <player-stats
            class=${this.isPlayerStatsShown ? "block min-w-0" : "hidden"}
            .game=${this.game}
            .eventBus=${this.eventBus}
            .visible=${this.isPlayerStatsShown}
          ></player-stats>
          <team-stats
            class=${this.isTeamStatsShown && this.isTeamGame
              ? "block min-w-0"
              : "hidden"}
            .game=${this.game}
            .visible=${this.isTeamStatsShown && this.isTeamGame}
          ></team-stats>
        </div>
        <slot></slot>
      </aside>
    `;
  }
}
