import { EventBus } from "@openfront/shared/EventBus";
import { Controller } from "../Controller";
import { AmbienceController } from "../controllers/AmbienceController";
import { AttackingTroopsController } from "../controllers/AttackingTroopsController";
import { BuildPreviewController } from "../controllers/BuildPreviewController";
import { HoverHighlightController } from "../controllers/HoverHighlightController";
import { LiveStatsController } from "../controllers/LiveStatsController";
import { MapLayerController } from "../controllers/MapLayerController";
import { SoundEffectController } from "../controllers/SoundEffectController";
import { StructureHighlightController } from "../controllers/StructureHighlightController";
import { ViewModeController } from "../controllers/ViewModeController";
import { WarshipSelectionController } from "../controllers/WarshipSelectionController";
import { GameStartingModal } from "../GameStartingModal";
import { migrateLegacyGraphicsSettings } from "../GraphicsPresets";
import { MapRenderer } from "../render/gl";
import { TransformHandler } from "../TransformHandler";
import { UIState } from "../UIState";
// The homepage loads it on demand, but the in-game instance (#game-settings)
// is set up below, so it has to be defined by the time a game renders.
import "../UserSettingModal";
import type { UserSettingModal } from "../UserSettingModal";
import { UserSettings } from "../UserSettings";
import { GameView } from "../view";
import { FrameProfiler } from "./FrameProfiler";
import { ActionableEvents } from "./layers/ActionableEvents";
import { AlertFrame } from "./layers/AlertFrame";
import { AttacksDisplay } from "./layers/AttacksDisplay";
import { BuildMenu } from "./layers/BuildMenu";
import { ChatDisplay } from "./layers/ChatDisplay";
import { ChatModal } from "./layers/ChatModal";
import { ControlPanel } from "./layers/ControlPanel";
import { EmojiTable } from "./layers/EmojiTable";
import { EventsDisplay } from "./layers/EventsDisplay";
import { GameLeftSidebar } from "./layers/GameLeftSidebar";
import { GameRightSidebar } from "./layers/GameRightSidebar";
import { HeadsUpMessage } from "./layers/HeadsUpMessage";
import { ImmunityTimer } from "./layers/ImmunityTimer";
import { InGamePromo } from "./layers/InGamePromo";
import { MainRadialMenu } from "./layers/MainRadialMenu";
import { MultiTabModal } from "./layers/MultiTabModal";
import { NewLobbyPrompt } from "./layers/NewLobbyPrompt";
import { PerformanceOverlay } from "./layers/PerformanceOverlay";
import { PlayerInfoOverlay } from "./layers/PlayerInfoOverlay";
import { PlayerPanel } from "./layers/PlayerPanel";
import { ReplayPanel } from "./layers/ReplayPanel";
import { SettingsModal } from "./layers/SettingsModal";
import { SpawnTimer } from "./layers/SpawnTimer";
import { TutorialPanel } from "./layers/TutorialPanel";
import { UnitDisplay } from "./layers/UnitDisplay";
import { PauseGameIntentEvent } from "../Transport";
import { DelegationPanel } from "./layers/DelegationPanel";
import { WarPlanPanel } from "./layers/WarPlanPanel";
import { DiplomacyBoard } from "./layers/DiplomacyBoard";
import { DiplomacyMapOverlay } from "./layers/DiplomacyMapOverlay";
import { DelegationZoneLayer } from "./layers/DelegationZoneLayer";
import { WarDashboard } from "./layers/WarDashboard";
import { WinModal } from "./layers/WinModal";
import { loadAllSprites } from "./SpriteLoader";

export function createRenderer(
  inputEl: HTMLElement,
  game: GameView,
  eventBus: EventBus,
  playerRole: string | null,
  view: MapRenderer,
  mapLayerController?: MapLayerController,
): GameRenderer {
  const transformHandler = new TransformHandler(game, eventBus, inputEl);
  const userSettings = new UserSettings();

  const uiState: UIState = {
    attackRatio: 20,
    paused: false,
    ghostStructure: null,
    rocketDirectionUp: true,
    upgradeMultiplier: 1,
  };

  // Single source of truth for "is the sim paused" that every HUD layer can
  // read synchronously (개선 7 queues attack clicks while it is true). Both
  // pause paths (pause button/keybind, settings auto-pause) emit this event.
  eventBus.on(PauseGameIntentEvent, (e) => {
    uiState.paused = e.paused;
  });

  //hide when the game renders
  const startingModal = document.querySelector(
    "game-starting-modal",
  ) as GameStartingModal;
  startingModal.hide();

  // TODO maybe append this to document instead of querying for them?
  const emojiTable = document.querySelector("emoji-table") as EmojiTable;
  if (!emojiTable || !(emojiTable instanceof EmojiTable)) {
    console.error("EmojiTable element not found in the DOM");
  }
  emojiTable.transformHandler = transformHandler;
  emojiTable.game = game;
  emojiTable.initEventBus(eventBus);

  const buildMenu = document.querySelector("build-menu") as BuildMenu;
  if (!buildMenu || !(buildMenu instanceof BuildMenu)) {
    console.error("BuildMenu element not found in the DOM");
  }
  buildMenu.game = game;
  buildMenu.eventBus = eventBus;
  buildMenu.uiState = uiState;
  buildMenu.transformHandler = transformHandler;

  const gameLeftSidebar = document.querySelector(
    "game-left-sidebar",
  ) as GameLeftSidebar;
  if (!gameLeftSidebar || !(gameLeftSidebar instanceof GameLeftSidebar)) {
    console.error("GameLeftSidebar element not found in the DOM");
  }
  gameLeftSidebar.game = game;
  gameLeftSidebar.eventBus = eventBus;

  const controlPanel = document.querySelector("control-panel") as ControlPanel;
  if (!(controlPanel instanceof ControlPanel)) {
    console.error("ControlPanel element not found in the DOM");
  }
  controlPanel.eventBus = eventBus;
  controlPanel.uiState = uiState;
  controlPanel.game = game;

  const eventsDisplay = document.querySelector(
    "events-display",
  ) as EventsDisplay;
  if (!(eventsDisplay instanceof EventsDisplay)) {
    console.error("events display not found");
  }
  eventsDisplay.eventBus = eventBus;
  eventsDisplay.game = game;
  eventsDisplay.uiState = uiState;

  const actionableEvents = document.querySelector(
    "actionable-events",
  ) as ActionableEvents;
  if (!(actionableEvents instanceof ActionableEvents)) {
    console.error("actionable events not found");
  }
  actionableEvents.eventBus = eventBus;
  actionableEvents.game = game;
  actionableEvents.uiState = uiState;

  const attacksDisplay = document.querySelector(
    "attacks-display",
  ) as AttacksDisplay;
  if (!(attacksDisplay instanceof AttacksDisplay)) {
    console.error("attacks display not found");
  }
  attacksDisplay.eventBus = eventBus;
  attacksDisplay.game = game;
  attacksDisplay.uiState = uiState;

  const chatDisplay = document.querySelector("chat-display") as ChatDisplay;
  if (!(chatDisplay instanceof ChatDisplay)) {
    console.error("chat display not found");
  }
  chatDisplay.eventBus = eventBus;
  chatDisplay.game = game;

  const playerInfo = document.querySelector(
    "player-info-overlay",
  ) as PlayerInfoOverlay;
  if (!(playerInfo instanceof PlayerInfoOverlay)) {
    console.error("player info overlay not found");
  }
  playerInfo.eventBus = eventBus;
  playerInfo.transform = transformHandler;
  playerInfo.game = game;

  const winModal = document.querySelector("win-modal") as WinModal;
  if (!(winModal instanceof WinModal)) {
    console.error("win modal not found");
  }
  winModal.eventBus = eventBus;
  winModal.game = game;

  const newLobbyPrompt = document.querySelector(
    "new-lobby-prompt",
  ) as NewLobbyPrompt;
  if (!(newLobbyPrompt instanceof NewLobbyPrompt)) {
    console.error("new lobby prompt not found");
  }
  newLobbyPrompt.eventBus = eventBus;
  newLobbyPrompt.game = game;

  const replayPanel = document.querySelector("replay-panel") as ReplayPanel;
  if (!(replayPanel instanceof ReplayPanel)) {
    console.error("replay panel not found");
  }
  replayPanel.eventBus = eventBus;
  replayPanel.game = game;

  const gameRightSidebar = document.querySelector(
    "game-right-sidebar",
  ) as GameRightSidebar;
  if (!(gameRightSidebar instanceof GameRightSidebar)) {
    console.error("Game Right bar not found");
  }
  gameRightSidebar.game = game;
  gameRightSidebar.eventBus = eventBus;

  const warDashboard = document.querySelector(
    "war-dashboard",
  ) as WarDashboard;
  if (!(warDashboard instanceof WarDashboard)) {
    console.error("war dashboard not found");
  }
  warDashboard.game = game;
  warDashboard.eventBus = eventBus;

  const diplomacyBoard = document.querySelector(
    "diplomacy-board",
  ) as DiplomacyBoard;
  if (!(diplomacyBoard instanceof DiplomacyBoard)) {
    console.error("diplomacy board not found");
  }
  diplomacyBoard.game = game;
  diplomacyBoard.eventBus = eventBus;

  const diplomacyMapOverlay = document.querySelector(
    "diplomacy-map-overlay",
  ) as DiplomacyMapOverlay;
  if (!(diplomacyMapOverlay instanceof DiplomacyMapOverlay)) {
    console.error("diplomacy map overlay not found");
  }
  diplomacyMapOverlay.game = game;
  diplomacyMapOverlay.eventBus = eventBus;
  diplomacyMapOverlay.transform = transformHandler;

  const delegationZoneLayer = document.querySelector(
    "delegation-zone-layer",
  ) as DelegationZoneLayer;
  if (!(delegationZoneLayer instanceof DelegationZoneLayer)) {
    console.error("delegation zone layer not found");
  }
  delegationZoneLayer.game = game;
  delegationZoneLayer.eventBus = eventBus;
  delegationZoneLayer.transform = transformHandler;

  const delegationPanel = document.querySelector(
    "delegation-panel",
  ) as DelegationPanel;
  if (!(delegationPanel instanceof DelegationPanel)) {
    console.error("delegation panel not found");
  }
  delegationPanel.game = game;
  delegationPanel.eventBus = eventBus;

  const warPlanPanel = document.querySelector("war-plan-panel") as WarPlanPanel;
  if (!(warPlanPanel instanceof WarPlanPanel)) {
    console.error("war plan panel not found");
  }
  warPlanPanel.game = game;
  warPlanPanel.eventBus = eventBus;
  warPlanPanel.uiState = uiState;

  const settingsModal = document.querySelector(
    "settings-modal",
  ) as SettingsModal;
  if (!(settingsModal instanceof SettingsModal)) {
    console.error("settings modal not found");
  }
  settingsModal.eventBus = eventBus;
  settingsModal.gameConfig = game.config().gameConfig();
  settingsModal.mapNationCount = game.mapNationCount();

  // The in-game settings instance needs the bus so the Audio sliders reach
  // SoundManager, which caches its volumes at construction, and UIState so the
  // attack ratio slider shows the session value the HUD slider may have set.
  // It also owns the advanced graphics options now, so it takes this game's
  // map layers and the two renderer callbacks they apply through — the rest of
  // those options reach the renderer through the settings-changed event
  // ClientGameRunner listens for.
  const gameSettingsModal = document.getElementById(
    "game-settings",
  ) as UserSettingModal | null;
  if (gameSettingsModal === null) {
    console.warn("In-game settings modal (#game-settings) not found");
  } else {
    gameSettingsModal.uiState = uiState;
    gameSettingsModal.mapLayers = game.layers();
    gameSettingsModal.onLayerVisibilityChange = (layerId, visible) => {
      view.setLayerVisible(layerId, visible);
    };
    gameSettingsModal.onLayerAlphaChange = (layerId, alpha) => {
      view.setLayerAlpha(layerId, alpha);
    };
  }

  // Ran from the graphics modal's init() before that modal was folded into the
  // settings modal's Graphics tab. Still game start, so a player who tuned
  // their graphics before presets existed keeps that snapshot whether or not
  // they ever open settings.
  migrateLegacyGraphicsSettings(userSettings);

  const unitDisplay = document.querySelector("unit-display") as UnitDisplay;
  if (!(unitDisplay instanceof UnitDisplay)) {
    console.error("unit display not found");
  }
  unitDisplay.game = game;
  unitDisplay.eventBus = eventBus;
  unitDisplay.uiState = uiState;

  const playerPanel = document.querySelector("player-panel") as PlayerPanel;
  if (!(playerPanel instanceof PlayerPanel)) {
    console.error("player panel not found");
  }
  playerPanel.g = game;
  playerPanel.initEventBus(eventBus);
  playerPanel.emojiTable = emojiTable;
  playerPanel.uiState = uiState;

  playerPanel.setRole(playerRole);

  const chatModal = document.querySelector("chat-modal") as ChatModal;
  if (!(chatModal instanceof ChatModal)) {
    console.error("chat modal not found");
  }
  chatModal.g = game;
  chatModal.transformHandler = transformHandler;
  chatModal.initEventBus(eventBus);

  const multiTabModal = document.querySelector(
    "multi-tab-modal",
  ) as MultiTabModal;
  if (!(multiTabModal instanceof MultiTabModal)) {
    console.error("multi-tab modal not found");
  }
  multiTabModal.game = game;

  const headsUpMessage = document.querySelector(
    "heads-up-message",
  ) as HeadsUpMessage;
  if (!(headsUpMessage instanceof HeadsUpMessage)) {
    console.error("heads-up message not found");
  }
  headsUpMessage.game = game;

  const performanceOverlay = document.querySelector(
    "performance-overlay",
  ) as PerformanceOverlay;
  if (!(performanceOverlay instanceof PerformanceOverlay)) {
    console.error("performance overlay not found");
  }
  performanceOverlay.eventBus = eventBus;
  performanceOverlay.userSettings = userSettings;

  const alertFrame = document.querySelector("alert-frame") as AlertFrame;
  if (!(alertFrame instanceof AlertFrame)) {
    console.error("alert frame not found");
  }
  alertFrame.game = game;

  const spawnTimer = document.querySelector("spawn-timer") as SpawnTimer;
  if (!(spawnTimer instanceof SpawnTimer)) {
    console.error("spawn timer not found");
  }
  spawnTimer.game = game;
  spawnTimer.eventBus = eventBus;
  spawnTimer.transformHandler = transformHandler;

  const immunityTimer = document.querySelector(
    "immunity-timer",
  ) as ImmunityTimer;
  if (!(immunityTimer instanceof ImmunityTimer)) {
    console.error("immunity timer not found");
  }
  immunityTimer.game = game;
  immunityTimer.eventBus = eventBus;

  const inGamePromo = document.querySelector("in-game-promo") as InGamePromo;
  if (!(inGamePromo instanceof InGamePromo)) {
    console.error("in-game promo not found");
  }
  inGamePromo.game = game;

  const tutorialPanel = document.querySelector(
    "tutorial-panel",
  ) as TutorialPanel;
  if (!(tutorialPanel instanceof TutorialPanel)) {
    console.error("tutorial panel not found");
  }
  tutorialPanel.game = game;
  tutorialPanel.eventBus = eventBus;
  tutorialPanel.userSettings = userSettings;
  tutorialPanel.uiState = uiState;

  const layers: Controller[] = [
    new WarshipSelectionController(game, eventBus, transformHandler, view),
    new BuildPreviewController(
      game,
      eventBus,
      uiState,
      transformHandler,
      view,
      userSettings,
    ),
    new HoverHighlightController(game, eventBus, transformHandler, view),
    new LiveStatsController(game, eventBus),
    new StructureHighlightController(eventBus, view),
    new ViewModeController(eventBus, view),
    new AttackingTroopsController(game, eventBus, userSettings, view),
    new SoundEffectController(game, eventBus),
    new AmbienceController(game, eventBus, transformHandler),
    ...(mapLayerController ? [mapLayerController] : []),
    eventsDisplay,
    actionableEvents,
    attacksDisplay,
    chatDisplay,
    buildMenu,
    new MainRadialMenu(
      eventBus,
      game,
      transformHandler,
      emojiTable as EmojiTable,
      buildMenu,
      uiState,
      playerPanel,
    ),
    spawnTimer,
    immunityTimer,
    gameLeftSidebar,
    unitDisplay,
    warDashboard,
    diplomacyBoard,
    diplomacyMapOverlay,
    delegationZoneLayer,
    delegationPanel,
    warPlanPanel,
    gameRightSidebar,
    controlPanel,
    playerInfo,
    winModal,
    newLobbyPrompt,
    replayPanel,
    settingsModal,
    playerPanel,
    headsUpMessage,
    multiTabModal,
    inGamePromo,
    tutorialPanel,
    alertFrame,
    performanceOverlay,
  ];

  return new GameRenderer(
    transformHandler,
    uiState,
    layers,
    performanceOverlay,
  );
}

export class GameRenderer {
  private layerTickState = new Map<Controller, { lastTickAtMs: number }>();

  constructor(
    public transformHandler: TransformHandler,
    public uiState: UIState,
    private layers: Controller[],
    private performanceOverlay: PerformanceOverlay,
  ) {}

  initialize() {
    loadAllSprites().catch((err) =>
      console.warn("Failed to preload sprites:", err),
    );

    this.layers.forEach((l) => l.init?.());

    window.addEventListener("resize", () =>
      this.transformHandler.updateCanvasBoundingRect(),
    );

    //show whole map on startup
    this.transformHandler.centerAll(0.9);
  }

  tick() {
    const nowMs = performance.now();
    const shouldProfileTick = FrameProfiler.isEnabled();

    const tickLayerDurations: Record<string, number> = {};

    for (const layer of this.layers) {
      if (!layer.tick) {
        continue;
      }

      const state = this.layerTickState.get(layer) ?? {
        lastTickAtMs: -Infinity,
      };

      const intervalMs = layer.getTickIntervalMs?.() ?? 0;
      if (intervalMs > 0 && nowMs - state.lastTickAtMs < intervalMs) {
        this.layerTickState.set(layer, state);
        continue;
      }

      state.lastTickAtMs = nowMs;
      this.layerTickState.set(layer, state);

      const tickStart = shouldProfileTick ? performance.now() : 0;
      layer.tick();
      if (shouldProfileTick && tickStart !== 0) {
        const duration = performance.now() - tickStart;
        const label = layer.constructor?.name ?? "UnknownLayer";
        tickLayerDurations[label] = (tickLayerDurations[label] ?? 0) + duration;
      }
    }

    if (shouldProfileTick) {
      this.performanceOverlay.updateTickLayerMetrics(tickLayerDurations);
    }
  }
}
