#!/bin/bash
# 개선 9: defense delegation detailed settings (structure toggles, build
# priority, protected zone). Overwrites the touched sources wholesale.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="${GITHUB_WORKSPACE:-$PWD}"
for f in \
  packages/engine-api/src/game/DefenseDelegation.ts \
  packages/engine-api/src/Schemas.ts \
  packages/engine/src/execution/nation/DefensePostPlacement.ts \
  packages/engine/src/execution/nation/DefenseDelegationBehavior.ts \
  packages/engine/src/execution/DefenseDelegationExecution.ts \
  packages/engine/src/execution/ExecutionManager.ts \
  src/client/Transport.ts \
  src/client/DelegationZoneEvents.ts \
  src/client/ClientGameRunner.ts \
  src/client/hud/layers/DelegationPanel.ts \
  src/client/hud/layers/DelegationZoneLayer.ts \
  src/client/hud/GameRenderer.ts \
  index.html \
  resources/lang/ko.json \
  resources/lang/en.json \
  tests/DefenseDelegation.test.ts; do
  mkdir -p "$DEST/$(dirname "$f")"
  cp "$SRC/$f" "$DEST/$f"
done
