#!/bin/bash
set -e
cp -r /tmp/payload/files/. .
