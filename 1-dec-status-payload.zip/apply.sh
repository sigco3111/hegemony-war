#!/bin/bash
# 개선 13: delegation decision status
set -e
cp -r /tmp/payload/files/. .
