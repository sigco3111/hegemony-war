#!/bin/bash
# 개선 7 v3: 모바일 사이드바 겹침 수정 + 일시정지 중 실행 표기 구분
set -e
cp -r /tmp/payload/files/. .
echo "applied $(find /tmp/payload/files -type f | wc -l) files"
