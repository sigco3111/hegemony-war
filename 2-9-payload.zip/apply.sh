set -e
cp -r /tmp/payload/files/. ./
