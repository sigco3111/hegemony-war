set -e
cd /tmp/payload
cp src/client/LocalRecords.ts src/client/SinglePlayerModal.ts src/client/RecordsBackup.ts "$GITHUB_WORKSPACE/src/client/"
cp tests/RecordsBackup.test.ts "$GITHUB_WORKSPACE/tests/"
cp resources/lang/ko.json resources/lang/en.json "$GITHUB_WORKSPACE/resources/lang/"
