#!/bin/bash
# 개선 11 fix: delegation panel per-frame DelegationNote collection
set -e
cp -r /tmp/payload/files/. .
