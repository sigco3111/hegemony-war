#!/bin/bash
# 개선 11 economy delegation payload: overlay changed source files onto repo root.
set -e
cp -r /tmp/payload/files/. .
