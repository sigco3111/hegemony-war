import { TileRef } from "@openfront/engine-api/game/GameMap";
import {
  AllPlayers,
  GameType,
  Gold,
  PlayerID,
  Tick,
  UnitType,
} from "@openfront/engine-api/game/GameTypes";
import {
  AllPlayersStats,
  ClientID,
  Intent,
  Winner,
} from "@openfront/engine-api/Schemas";
import {
  CloseCode,
  CloseReason,
  isCloseReason,
  isTerminalClose,
} from "@openfront/shared/CloseCodes";
import {
  EventBus,
  EventConstructor,
  GameEvent,
} from "@openfront/shared/EventBus";
import {
  ClientHashMessage,
  ClientIntentMessage,
  ClientJoinMessage,
  ClientMessage,
  ClientPingMessage,
  ClientRejoinMessage,
  ClientReportMessage,
  ClientSendLiveStatsMessage,
  ClientSendWinnerMessage,
  ClientSpectateMessage,
  LiveStats,
  ReportReason,
  ServerMessage,
} from "@openfront/shared/WireSchemas";
import {
  createGameWireContext,
  decodeServerMessage,
  encodeClientMessage,
} from "@openfront/shared/ZbinWire";
import { ZbContext } from "@openfront/zbin";
import { ClientEnv, NoServerError } from "src/client/ClientEnv";
import { getPlayToken } from "./Auth";
import { LobbyConfig } from "./ClientGameRunner";
import { clientDevice, clientPlatform } from "./ClientPlatform";
import { isDesktopShell } from "./DesktopShell";
import { showInGameConfirm } from "./InGameModal";
import {
  SendKickPlayerIntentEvent,
  SendSpectateEvent,
  SendToggleGameStartTimer,
  SendUpdateGameConfigIntentEvent,
} from "./LobbyEvents";
import { DefensePriority } from "@openfront/engine-api/game/DefenseDelegation";
import { EconomyPriority } from "@openfront/engine-api/game/EconomyDelegation";
import { LocalServer } from "./LocalServer";
import { describeSocketClose } from "./SocketClose";
import { homeHref, translateText } from "./Utils";
import { PlayerView } from "./view";

export class PauseGameIntentEvent implements GameEvent {
  constructor(public readonly paused: boolean) {}
}

// 개선6: toggle the AI-managed rear-defense delegation and its treasury
// reserve share (0-90). Sent from the delegation panel. 개선 9 adds the
// detailed settings; the panel always sends its full current settings.
export class SetDefenseDelegationEvent implements GameEvent {
  constructor(
    public readonly enabled: boolean,
    public readonly reservePercent: number,
    public readonly buildPosts: boolean = true,
    public readonly buildSams: boolean = true,
    public readonly priority: DefensePriority = "reactive",
    public readonly zoneTile: number | null = null,
  ) {}
}

export class SetEconomyDelegationEvent implements GameEvent {
  constructor(
    public readonly enabled: boolean,
    public readonly reservePercent: number,
    public readonly buildCities?: boolean,
    public readonly buildFactories?: boolean,
    public readonly priority?: EconomyPriority,
    public readonly cityTarget?: number,
    public readonly factoryTarget?: number,
  ) {}
}

export class SendAllianceRequestIntentEvent implements GameEvent {
  constructor(
    public readonly requestor: PlayerView,
    public readonly recipient: PlayerView,
  ) {}
}

export class SendBreakAllianceIntentEvent implements GameEvent {
  constructor(
    public readonly requestor: PlayerView,
    public readonly recipient: PlayerView,
  ) {}
}

export class SendUpgradeStructureIntentEvent implements GameEvent {
  constructor(
    public readonly unitId: number,
    public readonly unitType: UnitType,
    public readonly amount: number = 1,
  ) {}
}

export class SendAllianceRejectIntentEvent implements GameEvent {
  constructor(public readonly requestor: PlayerView) {}
}

export class SendAllianceExtensionIntentEvent implements GameEvent {
  constructor(public readonly recipient: PlayerView) {}
}

export class SendSpawnIntentEvent implements GameEvent {
  constructor(public readonly tile: TileRef) {}
}

export class SendAttackIntentEvent implements GameEvent {
  constructor(
    public readonly targetID: PlayerID | null,
    public readonly troops: number,
  ) {}
}

/**
 * Troops for a counter-attack: the incoming attack's size, capped at what the
 * player would send. An attack whose count is not a finite number is ignored
 * rather than turning the whole intent into NaN.
 */
export function counterAttackTroops(
  incomingTroops: number,
  available: number,
): number {
  if (!Number.isFinite(incomingTroops)) return available;
  return Math.min(incomingTroops, available);
}

export class SendBoatAttackIntentEvent implements GameEvent {
  constructor(
    public readonly dst: TileRef,
    public readonly troops: number,
  ) {}
}

export class BuildUnitIntentEvent implements GameEvent {
  constructor(
    public readonly unit: UnitType,
    public readonly tile: TileRef,
    public readonly rocketDirectionUp?: boolean,
    public readonly amount?: number,
  ) {}
}

export class SendTargetPlayerIntentEvent implements GameEvent {
  constructor(public readonly targetID: PlayerID) {}
}

export class SendEmojiIntentEvent implements GameEvent {
  constructor(
    public readonly recipient: PlayerView | typeof AllPlayers,
    public readonly emoji: number,
  ) {}
}

export class SendDonateGoldIntentEvent implements GameEvent {
  constructor(
    public readonly recipient: PlayerView,
    public readonly gold: Gold | null,
  ) {}
}

export class SendDonateTroopsIntentEvent implements GameEvent {
  constructor(
    public readonly recipient: PlayerView,
    public readonly troops: number | null,
  ) {}
}

export class SendQuickChatEvent implements GameEvent {
  constructor(
    public readonly recipient: PlayerView,
    public readonly quickChatKey: string,
    public readonly target?: PlayerID,
  ) {}
}

export class SendEmbargoIntentEvent implements GameEvent {
  constructor(
    public readonly target: PlayerView,
    public readonly action: "start" | "stop",
  ) {}
}

export class SendEmbargoAllIntentEvent implements GameEvent {
  constructor(public readonly action: "start" | "stop") {}
}

export class SendDeleteUnitIntentEvent implements GameEvent {
  constructor(public readonly unitId: number) {}
}

export class CancelAttackIntentEvent implements GameEvent {
  constructor(public readonly attackID: string) {}
}

export class CancelBoatIntentEvent implements GameEvent {
  constructor(public readonly unitID: number) {}
}

export class SendWinnerEvent implements GameEvent {
  constructor(
    public readonly winner: Winner,
    public readonly allPlayersStats: AllPlayersStats,
  ) {}
}
export class SendLiveStatsEvent implements GameEvent {
  constructor(public readonly stats: LiveStats) {}
}
export class SendPlayerReportEvent implements GameEvent {
  constructor(
    public readonly reported: ClientID,
    public readonly reason: ReportReason,
  ) {}
}
// Emitted once a report has actually gone to the server, so the UI only
// marks a player as reported when it has been.
export class PlayerReportedEvent implements GameEvent {
  constructor(public readonly reported: ClientID) {}
}
export class SendHashEvent implements GameEvent {
  constructor(
    public readonly tick: Tick,
    public readonly hash: number,
  ) {}
}

// Emitted when the server tells us the host started a successor lobby, carrying
// the new game id to move the group to.
export class NewLobbyEvent implements GameEvent {
  constructor(public readonly gameID: string) {}
}

export class MoveWarshipIntentEvent implements GameEvent {
  constructor(
    public readonly unitIds: number[],
    public readonly tile: number,
  ) {}
}

// One-shot marker that this lobby has already sent us to a sibling, so a
// redirect can never become a bounce.
const poolRedirectLatch = (gameID: string) => `pool-redirect:${gameID}`;

// The lobby a redirect came FROM, carried across the navigation: the latch is
// keyed by the source, but only the target can see that the redirect worked.
const POOL_REDIRECT_FROM = "pool-redirect-from";

export class Transport {
  // Retry budget for a dropped game socket. The first retry is immediate (a
  // blip should not cost a second), then exponential from the base to the
  // cap with +/-25% jitter: about 90s nominal over ten attempts, 68-113s with
  // jitter — enough to ride out a router reboot or a worker restart, short
  // enough not to leave a frozen map on screen for minutes. Every requester
  // (onclose, ClientGameRunner's silence watchdog, a send on a closed
  // socket) goes through scheduleReconnect, so this is the only budget.
  static readonly RECONNECT_MAX_ATTEMPTS = 10;
  static readonly RECONNECT_BASE_DELAY_MS = 1000;
  static readonly RECONNECT_MAX_DELAY_MS = 15_000;

  private socket: WebSocket | null = null;

  private localServer: LocalServer;

  private buffer: ClientMessage[] = [];

  private onconnect: () => void;
  private onmessage: (msg: ServerMessage) => void;

  private pingInterval: number | null = null;
  private reconnectTimeout: number | null = null;
  // Consecutive retries that have not yet produced a server frame.
  private reconnectAttempts = 0;
  public readonly isLocal: boolean;
  // Latched by a terminal close (a rejection the server will repeat), by
  // exhausting the reconnect budget, and by leaving the game. Blocks
  // scheduleReconnect and connectRemote so nothing reopens the socket.
  private connectionRefused = false;

  // True once the server has responded to join/rejoin (via start or lobby_info),
  // proving the session is admitted and ready to accept gameplay intents.
  private isSessionReady = false;

  // clientID dictionary for the binary wire (see ZbinWire.ts), seeded from
  // the roster in the start message. Null until the game starts, which is
  // also the last moment a peer can send a dictionary-encoded field.
  private zbinCtx: ZbContext | null = null;

  // The bus outlives the transport (one per page, one transport per join),
  // so every subscription must be undone in leaveGame or a superseded
  // transport keeps answering the live game's events.
  private readonly unsubscribers: Array<() => void> = [];

  constructor(
    private lobbyConfig: LobbyConfig,
    private eventBus: EventBus,
  ) {
    // If gameRecord is not null, we are replaying an archived game.
    // For multiplayer games, GameConfig is not known until game starts.
    this.isLocal =
      this.lobbyConfig.gameRecord !== undefined ||
      this.lobbyConfig.gameStartInfo?.config.gameType === GameType.Singleplayer;

    this.subscribe(SendAllianceRequestIntentEvent, (e) =>
      this.onSendAllianceRequest(e),
    );
    this.subscribe(SendAllianceRejectIntentEvent, (e) =>
      this.onAllianceRejectUIEvent(e),
    );
    this.subscribe(SendAllianceExtensionIntentEvent, (e) =>
      this.onSendAllianceExtensionIntent(e),
    );
    this.subscribe(SendBreakAllianceIntentEvent, (e) =>
      this.onBreakAllianceRequestUIEvent(e),
    );
    this.subscribe(SendSpawnIntentEvent, (e) => this.onSendSpawnIntentEvent(e));
    this.subscribe(SendAttackIntentEvent, (e) => this.onSendAttackIntent(e));
    this.subscribe(SendUpgradeStructureIntentEvent, (e) =>
      this.onSendUpgradeStructureIntent(e),
    );
    this.subscribe(SendBoatAttackIntentEvent, (e) =>
      this.onSendBoatAttackIntent(e),
    );
    this.subscribe(SendTargetPlayerIntentEvent, (e) =>
      this.onSendTargetPlayerIntent(e),
    );
    this.subscribe(SendEmojiIntentEvent, (e) => this.onSendEmojiIntent(e));
    this.subscribe(SendDonateGoldIntentEvent, (e) =>
      this.onSendDonateGoldIntent(e),
    );
    this.subscribe(SendDonateTroopsIntentEvent, (e) =>
      this.onSendDonateTroopIntent(e),
    );
    this.subscribe(SendQuickChatEvent, (e) => this.onSendQuickChatIntent(e));
    this.subscribe(SendEmbargoIntentEvent, (e) => this.onSendEmbargoIntent(e));
    this.subscribe(SendEmbargoAllIntentEvent, (e) =>
      this.onSendEmbargoAllIntent(e),
    );
    this.subscribe(BuildUnitIntentEvent, (e) => this.onBuildUnitIntent(e));

    this.subscribe(PauseGameIntentEvent, (e) => this.onPauseGameIntent(e));
    this.subscribe(SetDefenseDelegationEvent, (e) =>
      this.onSetDefenseDelegation(e),
    );
    this.subscribe(SetEconomyDelegationEvent, (e) =>
      this.onSetEconomyDelegation(e),
    );
    this.subscribe(SendWinnerEvent, (e) => this.onSendWinnerEvent(e));
    this.subscribe(SendLiveStatsEvent, (e) => this.onSendLiveStatsEvent(e));
    this.subscribe(SendPlayerReportEvent, (e) =>
      this.onSendPlayerReportEvent(e),
    );
    this.subscribe(SendHashEvent, (e) => this.onSendHashEvent(e));
    this.subscribe(CancelAttackIntentEvent, (e) =>
      this.onCancelAttackIntentEvent(e),
    );
    this.subscribe(CancelBoatIntentEvent, (e) =>
      this.onCancelBoatIntentEvent(e),
    );

    this.subscribe(MoveWarshipIntentEvent, (e) => {
      this.onMoveWarshipEvent(e);
    });

    this.subscribe(SendDeleteUnitIntentEvent, (e) =>
      this.onSendDeleteUnitIntent(e),
    );

    this.subscribe(SendKickPlayerIntentEvent, (e) =>
      this.onSendKickPlayerIntent(e),
    );

    this.subscribe(SendUpdateGameConfigIntentEvent, (e) =>
      this.onSendUpdateGameConfigIntent(e),
    );

    this.subscribe(SendToggleGameStartTimer, (e) =>
      this.onSendToggleGameStartTimer(e),
    );
    this.subscribe(SendSpectateEvent, (e) => {
      this.lobbyConfig.spectator = e.spectator;
      this.sendMsg({
        type: "spectate",
        spectator: e.spectator,
      } satisfies ClientSpectateMessage);
    });
  }

  private subscribe<T extends GameEvent>(
    eventType: EventConstructor<T>,
    handler: (event: T) => void,
  ) {
    this.eventBus.on(eventType, handler);
    this.unsubscribers.push(() => this.eventBus.off(eventType, handler));
  }

  private startPing() {
    if (this.isLocal) return;
    this.pingInterval ??= window.setInterval(() => {
      if (this.socket !== null && this.socket.readyState === WebSocket.OPEN) {
        this.sendMsg({
          type: "ping",
          sentAt: Math.floor(performance.now()),
        } satisfies ClientPingMessage);
      }
    }, 5 * 1000);
  }

  private stopPing() {
    if (this.pingInterval) {
      window.clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  public connect(
    onconnect: () => void,
    onmessage: (message: ServerMessage) => void,
  ) {
    if (this.isLocal) {
      this.connectLocal(onconnect, onmessage);
    } else {
      this.connectRemote(onconnect, onmessage);
    }
  }

  public updateCallback(
    onconnect: () => void,
    onmessage: (message: ServerMessage) => void,
  ) {
    if (this.isLocal) {
      this.localServer.updateCallback(onconnect, onmessage);
    } else {
      this.onconnect = onconnect;
      this.onmessage = onmessage;
    }
  }

  private connectLocal(
    onconnect: () => void,
    onmessage: (message: ServerMessage) => void,
  ) {
    this.localServer = new LocalServer(
      this.lobbyConfig,
      this.lobbyConfig.gameRecord !== undefined,
      this.eventBus,
    );
    this.localServer.updateCallback(onconnect, onmessage);
    this.localServer.start();
  }

  private connectRemote(
    onconnect: () => void,
    onmessage: (message: ServerMessage) => void,
  ) {
    if (this.connectionRefused) {
      return;
    }
    this.isSessionReady = false;
    this.startPing();
    this.killExistingSocket();
    // WS origin comes from ClientEnv, resolved per game: the id's letter
    // names the hosting deployment, so a shared lobby link or rejoin works
    // from any shell in the fleet. Own/legacy ids keep the historical
    // behavior (same-origin on web, serverHost on the desktop app).
    // No server known at all (a static page whose list never loaded, and an
    // id whose letter nothing in it carries) means there is no worker to
    // dial. That is a connection that cannot be made, not a bug: route it
    // into the same terminal dialog a refused socket produces rather than
    // letting it escape as an unhandled exception from the join.
    let workerPath: string;
    try {
      workerPath = ClientEnv.gameWorkerPath(this.lobbyConfig.gameID);
    } catch (e) {
      if (!(e instanceof NoServerError)) throw e;
      console.warn("No server for game", this.lobbyConfig.gameID, e);
      this.handleConnectionRefused(CloseReason.Unknown);
      return;
    }
    const socket = new WebSocket(
      `${ClientEnv.gameWsBase(this.lobbyConfig.gameID)}/${workerPath}`,
    );
    this.socket = socket;
    let openedAt: number | null = null;
    // Every frame is a zbin payload; without this they would arrive as Blobs.
    this.socket.binaryType = "arraybuffer";
    this.onconnect = onconnect;
    this.onmessage = onmessage;
    this.socket.onopen = () => {
      openedAt = Date.now();
      console.log("Connected to game server!");
      if (this.socket === null) {
        console.error("socket is null");
        return;
      }
      onconnect();
    };
    this.socket.onmessage = (event: MessageEvent) => {
      // A frame from the server is the proof the connection is real; onopen
      // is not (a proxy can accept and drop us in a loop). It resets the
      // budget and settles any retry the watchdog scheduled while this
      // socket was silent — left armed, it would tear down the socket that
      // just recovered.
      this.reconnectAttempts = 0;
      this.cancelReconnect();
      try {
        const msg = decodeServerMessage(
          new Uint8Array(event.data as ArrayBuffer),
          this.zbinCtx ?? undefined,
        );
        if (msg.type === "redirect") {
          this.handlePoolRedirect(msg.gameID);
          return;
        }
        if (msg.type === "start") {
          // Seed the dictionary from the same players array, in the same
          // order, that the server seeded its own from.
          this.zbinCtx = createGameWireContext(msg.gameStartInfo.players);
        }
        if (msg.type === "lobby_info" || msg.type === "start") {
          // Admitted, so the redirect that sent us here is spent: drop the
          // source's latch so it can route this player again later. Any other
          // frame proves nothing — a full sibling sends an error frame first.
          const from = sessionStorage.getItem(POOL_REDIRECT_FROM);
          if (from !== null) {
            sessionStorage.removeItem(poolRedirectLatch(from));
            sessionStorage.removeItem(POOL_REDIRECT_FROM);
          }
        }
        this.isSessionReady = true;
        this.flushBuffer();
        this.onmessage(msg);
      } catch (e) {
        // Deliberately NOT the frame. This catch wraps the downstream
        // handler as well as the decode, so it fires on ordinary
        // application errors too — and the desktop shell persists
        // console.error by default, while a lobby_info or start frame
        // carries the game's group token in the clear. For a decode failure
        // the size is the part that actually helps.
        //
        // The size goes in its own argument rather than interpolated into
        // the first one: console.* treats argument one as a format string
        // (%s, %d, %o), so building it from anything that came off the wire
        // is a format-string sink even when the value can only ever be
        // digits (CodeQL js/tainted-format-string).
        const frame =
          event.data instanceof ArrayBuffer
            ? `${event.data.byteLength} bytes`
            : typeof event.data;
        console.error("Error in onmessage handler:", e, "frame:", frame);
        return;
      }
    };
    this.socket.onerror = () => {
      if (this.socket === null) {
        return;
      }
      this.socket.close();
    };
    this.socket.onclose = (event: CloseEvent) => {
      this.isSessionReady = false;
      const detail = describeSocketClose(socket.url, event, openedAt);
      if (event.code === CloseCode.Normal) {
        console.log(`Game socket ${detail}`);
      } else {
        const next = isTerminalClose(event.code)
          ? "not retrying"
          : "reconnecting";
        console.warn(`Game socket ${detail}; ${next}`);
      }
      if (isTerminalClose(event.code)) {
        if (event.code === CloseCode.Normal) {
          // The server ended the session (game over, kick): nothing to say
          // and nothing to retry. Latch, or the silence watchdog would open
          // a fresh socket 5s later only to be refused with "game not found".
          this.connectionRefused = true;
          this.stopPing();
        } else {
          this.handleConnectionRefused(event.reason);
        }
        return;
      }
      this.scheduleReconnect();
    };
  }

  // The lobby we asked for assigned us to a sibling. Getting here twice is
  // ordinary — sent to a sibling, found it full, came back — so the latched
  // branch falls through to the refusal dialog rather than leaving a dead
  // loading screen, the way the WrongWorker recovery below does.
  //
  // The search string is dropped: it belongs to the lobby we asked for, not
  // the one we land on.
  private handlePoolRedirect(gameID: string) {
    const from = this.lobbyConfig.gameID;
    const latch = poolRedirectLatch(from);
    if (sessionStorage.getItem(latch) !== null) {
      this.handleConnectionRefused(CloseReason.PoolRedirect);
      return;
    }
    sessionStorage.setItem(latch, "1");
    sessionStorage.setItem(POOL_REDIRECT_FROM, from);
    window.location.href = ClientEnv.gamePath(gameID);
  }

  private handleConnectionRefused(reason: string) {
    if (this.connectionRefused) {
      return;
    }
    this.connectionRefused = true;
    this.stopPing();
    // WrongWorker: the worker says it doesn't own this game, which means
    // this bundle routed with a stale worker count. One full navigation to
    // the game's own host re-fetches shell + cluster map and re-resolves;
    // the sessionStorage latch stops a loop if the fresh map still
    // misroutes (a real bug), falling through to the dialog instead. Not on
    // desktop: its shell owns navigation and updates its map at boot.
    if (reason === CloseReason.WrongWorker && !isDesktopShell()) {
      const gameID = this.lobbyConfig.gameID;
      const latch = `wrong-worker-redirect:${gameID}`;
      if (sessionStorage.getItem(latch) === null) {
        sessionStorage.setItem(latch, "1");
        // gameNavigateBase, not gameHttpBase: this is a page load, and the
        // HTTP base throws when no game server is known. A tab that got here
        // has one (the worker answered), but a navigation must not depend on
        // that — every page host serves `/game/<id>`.
        window.location.href = `${ClientEnv.gameNavigateBase(gameID)}/game/${gameID}${window.location.search}`;
        return;
      }
    }
    // The reason is a close_reason.* key the server chose. Anything else (a
    // proxy closing on its own, an empty reason) gets the generic text
    // rather than a bare key.
    const reasonKey = isCloseReason(reason) ? reason : CloseReason.Unknown;
    this.showTerminalDialog(
      translateText("error_modal.connection_refused", {
        reason: translateText(reasonKey),
      }),
    );
  }

  // The session is over: say so once, offer the menu, and let the player
  // stay to look at the map if they would rather.
  private showTerminalDialog(message: string) {
    void showInGameConfirm(message, {
      variant: "warning",
      confirmText: translateText("win_modal.exit"),
      cancelText: translateText("common.close"),
    }).then((goHome) => {
      if (goHome) {
        window.location.href = homeHref();
      }
    });
  }

  // Ask for a reconnect. Callers do not decide when (or whether) it happens:
  // one attempt is scheduled at a time, on the backoff schedule, until the
  // budget runs out.
  public reconnect() {
    if (this.isLocal) {
      this.connect(this.onconnect, this.onmessage);
      return;
    }
    this.scheduleReconnect();
  }

  private scheduleReconnect() {
    if (this.connectionRefused || this.reconnectTimeout !== null) {
      return;
    }
    // An attempt is already in flight; let it succeed or fail on its own.
    if (this.socket?.readyState === WebSocket.CONNECTING) {
      return;
    }
    if (this.reconnectAttempts >= Transport.RECONNECT_MAX_ATTEMPTS) {
      console.warn(
        `giving up after ${this.reconnectAttempts} reconnect attempts`,
      );
      this.connectionRefused = true;
      this.stopPing();
      this.showTerminalDialog(translateText("error_modal.connection_lost"));
      return;
    }
    this.reconnectAttempts++;
    const delay = Transport.reconnectDelay(this.reconnectAttempts);
    console.log(
      `reconnect attempt ${this.reconnectAttempts}/${Transport.RECONNECT_MAX_ATTEMPTS} in ${delay} ms`,
    );
    this.reconnectTimeout = window.setTimeout(() => {
      this.reconnectTimeout = null;
      this.connectRemote(this.onconnect, this.onmessage);
    }, delay);
  }

  // Delay before the n-th consecutive attempt (1-based).
  static reconnectDelay(attempt: number): number {
    if (attempt <= 1) {
      return 0;
    }
    const nominal = Math.min(
      Transport.RECONNECT_MAX_DELAY_MS,
      Transport.RECONNECT_BASE_DELAY_MS * 2 ** (attempt - 2),
    );
    // Jitter so a fleet of clients dropped by one worker restart does not
    // come back in lockstep.
    return Math.round(nominal * (0.75 + Math.random() * 0.5));
  }

  private cancelReconnect() {
    if (this.reconnectTimeout !== null) {
      window.clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
  }

  public turnComplete() {
    if (this.isLocal) {
      this.localServer.turnComplete();
    }
  }

  async joinGame() {
    // Only the first join: the token is short-lived, and a later reconnect
    // must not present one that has since expired.
    const token = this.lobbyConfig.creatorToken ?? (await getPlayToken());
    delete this.lobbyConfig.creatorToken;
    this.sendMsg({
      type: "join",
      gameID: this.lobbyConfig.gameID,
      // Note: clientID is not sent - server assigns it based on persistentID
      username: this.lobbyConfig.playerName,
      clanTag: this.lobbyConfig.playerClanTag ?? null,
      cosmetics: this.lobbyConfig.cosmetics,
      turnstileToken: this.lobbyConfig.turnstileToken,
      token,
      spectator: this.lobbyConfig.spectator,
      gitCommit: ClientEnv.gitCommit(),
      platform: clientPlatform(),
      device: clientDevice(),
    } satisfies ClientJoinMessage);
  }

  async rejoinGame(lastTurn: number) {
    this.sendMsg({
      type: "rejoin",
      gameID: this.lobbyConfig.gameID,
      // Note: clientID is not sent - server looks it up from persistentID in token
      lastTurn: lastTurn,
      token: await getPlayToken(),
      gitCommit: ClientEnv.gitCommit(),
    } satisfies ClientRejoinMessage);
  }

  leaveGame() {
    for (const unsubscribe of this.unsubscribers.splice(0)) {
      unsubscribe();
    }
    if (this.isLocal) {
      this.localServer.endGame();
      return;
    }
    // A left game is never rejoined through this transport, whatever still
    // asks (the watchdog, a late send).
    this.connectionRefused = true;
    this.stopPing();
    this.cancelReconnect();
    if (this.socket === null) {
      return;
    }
    if (this.socket.readyState === WebSocket.OPEN) {
      console.log("on stop: leaving game");
    } else {
      console.log(
        "WebSocket is not open. Current state:",
        this.socket.readyState,
      );
    }
    this.killExistingSocket();
  }

  private onSendAllianceRequest(event: SendAllianceRequestIntentEvent) {
    this.sendIntent({
      type: "allianceRequest",
      recipient: event.recipient.id(),
    });
  }

  private onAllianceRejectUIEvent(event: SendAllianceRejectIntentEvent) {
    this.sendIntent({
      type: "allianceReject",
      requestor: event.requestor.id(),
    });
  }

  private onBreakAllianceRequestUIEvent(event: SendBreakAllianceIntentEvent) {
    this.sendIntent({
      type: "breakAlliance",
      recipient: event.recipient.id(),
    });
  }

  private onSendAllianceExtensionIntent(
    event: SendAllianceExtensionIntentEvent,
  ) {
    this.sendIntent({
      type: "allianceExtension",
      recipient: event.recipient.id(),
    });
  }

  private onSendSpawnIntentEvent(event: SendSpawnIntentEvent) {
    this.sendIntent({
      type: "spawn",
      tile: event.tile,
    });
  }

  private onSendAttackIntent(event: SendAttackIntentEvent) {
    if (!this.isSendableTroops("attack", event.troops)) return;
    this.sendIntent({
      type: "attack",
      targetID: event.targetID,
      troops: event.troops,
    });
  }

  private onSendBoatAttackIntent(event: SendBoatAttackIntentEvent) {
    if (!this.isSendableTroops("boat", event.troops)) return;
    this.sendIntent({
      type: "boat",
      troops: event.troops,
      dst: event.dst,
    });
  }

  private onSendUpgradeStructureIntent(event: SendUpgradeStructureIntentEvent) {
    this.sendIntent({
      type: "upgrade_structure",
      unit: event.unitType,
      unitId: event.unitId,
      amount: event.amount,
    });
  }

  private onSendTargetPlayerIntent(event: SendTargetPlayerIntentEvent) {
    this.sendIntent({
      type: "targetPlayer",
      target: event.targetID,
    });
  }

  private onSendEmojiIntent(event: SendEmojiIntentEvent) {
    this.sendIntent({
      type: "emoji",
      recipient:
        event.recipient === AllPlayers ? AllPlayers : event.recipient.id(),
      emoji: event.emoji,
    });
  }

  private onSendDonateGoldIntent(event: SendDonateGoldIntentEvent) {
    this.sendIntent({
      type: "donate_gold",
      recipient: event.recipient.id(),
      gold: event.gold ? Number(event.gold) : null,
    });
  }

  private onSendDonateTroopIntent(event: SendDonateTroopsIntentEvent) {
    this.sendIntent({
      type: "donate_troops",
      recipient: event.recipient.id(),
      troops: event.troops,
    });
  }

  private onSendQuickChatIntent(event: SendQuickChatEvent) {
    this.sendIntent({
      type: "quick_chat",
      recipient: event.recipient.id(),
      quickChatKey: event.quickChatKey,
      target: event.target,
    });
  }

  private onSendEmbargoIntent(event: SendEmbargoIntentEvent) {
    this.sendIntent({
      type: "embargo",
      targetID: event.target.id(),
      action: event.action,
    });
  }

  private onSendEmbargoAllIntent(event: SendEmbargoAllIntentEvent) {
    this.sendIntent({
      type: "embargo_all",
      action: event.action,
    });
  }

  private onBuildUnitIntent(event: BuildUnitIntentEvent) {
    this.sendIntent({
      type: "build_unit",
      unit: event.unit,
      tile: event.tile,
      rocketDirectionUp: event.rocketDirectionUp,
      amount: event.amount,
    });
  }

  private onPauseGameIntent(event: PauseGameIntentEvent) {
    this.sendIntent({
      type: "toggle_pause",
      paused: event.paused,
    });
  }

  private onSetDefenseDelegation(event: SetDefenseDelegationEvent) {
    this.sendIntent({
      type: "set_defense_delegation",
      enabled: event.enabled,
      reservePercent: event.reservePercent,
      buildPosts: event.buildPosts,
      buildSams: event.buildSams,
      priority: event.priority,
      zoneTile: event.zoneTile,
    });
  }

  private onSetEconomyDelegation(event: SetEconomyDelegationEvent) {
    this.sendIntent({
      type: "set_economy_delegation",
      enabled: event.enabled,
      reservePercent: event.reservePercent,
      buildCities: event.buildCities,
      buildFactories: event.buildFactories,
      priority: event.priority,
      cityTarget: event.cityTarget,
      factoryTarget: event.factoryTarget,
    });
  }

  private onSendWinnerEvent(event: SendWinnerEvent) {
    if (this.isLocal || this.socket?.readyState === WebSocket.OPEN) {
      this.sendMsg({
        type: "winner",
        winner: event.winner,
        allPlayersStats: event.allPlayersStats,
      } satisfies ClientSendWinnerMessage);
    } else {
      console.log(
        "WebSocket is not open. Current state:",
        this.socket?.readyState,
      );
    }
  }

  private onSendLiveStatsEvent(event: SendLiveStatsEvent) {
    if (this.isLocal || this.socket?.readyState === WebSocket.OPEN) {
      this.sendMsg({
        type: "live_stats",
        stats: event.stats,
      } satisfies ClientSendLiveStatsMessage);
    }
  }

  private onSendPlayerReportEvent(event: SendPlayerReportEvent) {
    // Singleplayer records are client-authored and the API ignores their
    // reports, so there is nowhere for one to go.
    if (this.isLocal) return;
    if (this.socket?.readyState !== WebSocket.OPEN) {
      console.log(
        "WebSocket is not open, dropping report. Current state:",
        this.socket?.readyState,
      );
      return;
    }
    this.sendMsg({
      type: "report",
      reported: event.reported,
      reason: event.reason,
    } satisfies ClientReportMessage);
    this.eventBus.emit(new PlayerReportedEvent(event.reported));
  }

  private onSendHashEvent(event: SendHashEvent) {
    if (this.isLocal || this.socket?.readyState === WebSocket.OPEN) {
      this.sendMsg({
        type: "hash",
        turnNumber: event.tick,
        hash: event.hash,
      } satisfies ClientHashMessage);
    } else {
      console.log(
        "WebSocket is not open. Current state:",
        this.socket?.readyState,
      );
    }
  }

  private onCancelAttackIntentEvent(event: CancelAttackIntentEvent) {
    this.sendIntent({
      type: "cancel_attack",
      attackID: event.attackID,
    });
  }

  private onCancelBoatIntentEvent(event: CancelBoatIntentEvent) {
    this.sendIntent({
      type: "cancel_boat",
      unitID: event.unitID,
    });
  }

  private onMoveWarshipEvent(event: MoveWarshipIntentEvent) {
    this.sendIntent({
      type: "move_warship",
      unitIds: event.unitIds,
      tile: event.tile,
    });
  }

  private onSendDeleteUnitIntent(event: SendDeleteUnitIntentEvent) {
    this.sendIntent({
      type: "delete_unit",
      unitId: event.unitId,
    });
  }

  private onSendKickPlayerIntent(event: SendKickPlayerIntentEvent) {
    this.sendIntent({
      type: "kick_player",
      targetClientID: event.target,
    });
  }

  private onSendUpdateGameConfigIntent(event: SendUpdateGameConfigIntentEvent) {
    this.sendIntent({
      type: "update_game_config",
      config: event.config,
    });
  }

  private onSendToggleGameStartTimer(event: SendToggleGameStartTimer) {
    this.sendIntent({ type: "toggle_game_start_timer" });
  }

  // The intent schemas take troops as a finite float >= 0, and the server
  // kicks a client whose message fails to parse. Drop the one intent instead,
  // and log it with a stack (console.error reaches telemetry) so the caller
  // that produced the bad count shows up.
  private isSendableTroops(type: Intent["type"], troops: number): boolean {
    if (Number.isFinite(troops) && troops >= 0) return true;
    console.error(
      new Error(`Dropped ${type} intent with invalid troops: ${troops}`),
    );
    return false;
  }

  private sendIntent(intent: Intent) {
    const msg = {
      type: "intent",
      intent: intent,
    } satisfies ClientIntentMessage;
    this.sendMsg(msg);
  }

  private flushBuffer(): void {
    if (this.socket === null || this.socket.readyState !== WebSocket.OPEN) {
      return;
    }
    while (this.buffer.length > 0) {
      console.log("sending dropped message");
      const msg = this.buffer.shift();
      if (msg === undefined) {
        console.warn("msg is undefined");
        continue;
      }
      this.socket.send(encodeClientMessage(msg, this.zbinCtx ?? undefined));
    }
  }

  private sendMsg(msg: ClientMessage): void {
    if (this.connectionRefused) {
      return;
    }
    if (this.isLocal) {
      // Route to the in-process server; nothing goes over the wire.
      this.localServer.onMessage(msg);
      return;
    } else if (this.socket === null) {
      return;
    }

    const isHandshakeMsg =
      msg.type === "join" || msg.type === "rejoin" || msg.type === "ping";

    if (this.socket.readyState !== WebSocket.OPEN) {
      // Buffer the message for the next successful open.
      console.warn("socket not ready, buffering and reconnecting");
      this.buffer.push(msg);
      this.scheduleReconnect();
    } else if (
      !isHandshakeMsg &&
      (!this.isSessionReady || this.buffer.length > 0)
    ) {
      // Hold non-handshake messages until the session handshake is complete,
      // and keep them queued behind any previously buffered messages.
      this.buffer.push(msg);
    } else {
      // Session is ready and nothing is queued ahead: send directly.
      this.socket.send(encodeClientMessage(msg, this.zbinCtx ?? undefined));
    }
  }

  private killExistingSocket(): void {
    this.isSessionReady = false;
    if (this.socket === null) {
      return;
    }
    // Remove all event listeners
    this.socket.onmessage = null;
    this.socket.onopen = null;
    this.socket.onclose = null;
    this.socket.onerror = null;

    // Close the connection if it's still open or still connecting
    try {
      if (
        this.socket.readyState === WebSocket.OPEN ||
        this.socket.readyState === WebSocket.CONNECTING
      ) {
        this.socket.close();
      }
    } catch (e) {
      console.warn("Error while closing WebSocket:", e);
    }

    this.socket = null;
  }
}
