set -e
cd /tmp/payload
cp resources/lang/en.json resources/lang/ko.json resources/lang/
cp src/client/hud/layers/DelegationPanel.ts src/client/hud/layers/
cp docs/DESIGN.md docs/
