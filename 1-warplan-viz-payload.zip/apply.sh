#!/bin/bash
# 개선 10 war-plan visualization payload: overlay changed source files onto repo root.
set -e
cp -r /tmp/payload/files/. .
