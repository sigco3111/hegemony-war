set -e
cd /tmp/payload
cp src/client/LocalRecords.ts src/client/SinglePlayerModal.ts src/client/RecordsBackup.ts "$GITHUB_WORKSPACE/src/client/"
cp tests/RecordsBackup.test.ts "$GITHUB_WORKSPACE/tests/"
cp resources/lang/ko.json resources/lang/en.json "$GITHUB_WORKSPACE/resources/lang/"
# Remove the stray v2 zip whose name missed the *payload.zip glob.
rm -f "$GITHUB_WORKSPACE"/1-records-backup-payload2.zip
