import { Howl, Howler } from "howler";
import { Platform } from "../Platform";
import { ClientEnv } from "../ClientEnv";
import {
  AudioCategory,
  USER_SETTINGS_CHANGED_EVENT,
  UserSettings,
} from "../UserSettings";
import { setAudioControls, setCuePlayer } from "./CuePlayer";
import {
  AmbienceTrack,
  categoryOf,
  CueCategory,
  SoundEffect,
  soundEffectUrls,
} from "./Sounds";

/** Every channel a sound can actually play on. */
export type PlayableCategory = Exclude<AudioCategory, "master">;

/**
 * Whether the two music tracks stream from a media element instead of being
 * decoded into memory up front.
 *
 * False only on iOS, which ignores volume writes to a media element: a
 * streamed track there cannot be turned down or muted at all, which is the
 * whole of #5457. Web Audio is the only path with a working gain, so iOS
 * takes it despite the cost -- the decoded track is roughly an order of
 * magnitude larger than the file, so it is never loaded until the music
 * channel is audible (SoundManager, MenuMusic).
 *
 * Cues and ambience are Web Audio everywhere and were never affected.
 *
 * A function, not a constant: it is read when a track is built, so a test can
 * stand in a different platform without re-importing the module graph.
 */
export function streamsMusic(): boolean {
  return !Platform.isIOS;
}

const PLAYABLE: readonly PlayableCategory[] = [
  "music",
  "effects",
  "alerts",
  "ambience",
  "interface",
];

/**
 * Slider positions are linear but perceived loudness is roughly logarithmic,
 * so feeding the position straight to Howler makes the top of the range sound
 * identical. Squaring gives an audio taper.
 */
export function perceptualGain(position: number): number {
  const clamped = Math.max(0, Math.min(1, position));
  return clamped * clamped;
}

/**
 * Fixed per-channel trim, applied under the player's slider.
 *
 * The sound designer re-bounced the delivery 2 dB down, so effects need no
 * further attenuation — the -5 dB that used to sit here was written for the
 * older masters and stacked with the re-bounce. Music is the only material
 * whose inter-sample peaks still exceed 0 dBFS (+0.11 and +0.19 dBTP), so it
 * is the one channel that takes a trim. Ambience is attenuated by the zoom
 * envelope in AmbienceController, not here.
 */
const CATEGORY_TRIM: Record<PlayableCategory, number> = {
  music: 0.89, // -1 dB
  effects: 1,
  alerts: 1,
  ambience: 1,
  interface: 1,
};

/**
 * Limiter, not compressor: a hard knee leaves everything below the threshold
 * completely untouched and holds the peaks just under 0 dBFS, rather than
 * shaping the whole signal. 20:1 is the Web Audio maximum ratio. The attack
 * is fast enough to catch a cue transient without being so instant that it
 * distorts low frequencies.
 */
const LIMITER_THRESHOLD_DB = -3;
const LIMITER_RATIO = 20;
const LIMITER_ATTACK_S = 0.003;
const LIMITER_RELEASE_S = 0.25;

/**
 * Concurrent one-shots per channel, replacing a single global cap. Budgets
 * never cross channels, so a burst of combat cannot silence an alert.
 */
const BUDGET: Record<CueCategory, number> = {
  effects: 6,
  alerts: 3,
  interface: 4,
  ambience: 2,
};

/**
 * Interface ticks drop the newest instead of stealing the oldest: a fifth tick
 * inside one drag is inaudible anyway, and stealing makes the ratchet stutter.
 */
const DROP_NEWEST: ReadonlySet<CueCategory> = new Set<CueCategory>([
  "interface",
]);

/** Representative cue per channel for the settings tab's test buttons. */
const PREVIEW_CUE: Record<Exclude<CueCategory, "ambience">, SoundEffect> = {
  effects: "build-city",
  alerts: "nuke-warning",
  interface: "click",
};

// Evicting with a hard stop clicks. Duck out over a few frames instead.
const EVICT_FADE_MS = 60;

interface ActiveSound {
  howl: Howl;
  id: number;
  category: CueCategory;
  /**
   * What finishing means for this playback. Held here as well as in the
   * Howler listeners so that a cue which can never finish on its own -- a
   * file that would not load -- can still be settled by whoever gives up on
   * it, without that code needing to know what any given cue was for.
   */
  done: () => void;
}

/**
 * Owns everything about how loud a sound is: the six channels, the window
 * focus duck, and the per-channel concurrency budgets.
 *
 * One instance per page, created in Main.ts, so the home page's menu theme and
 * the in-game SoundManager share it. It follows UserSettings directly through
 * USER_SETTINGS_CHANGED_EVENT rather than an EventBus, because the page and a
 * running game have different bus instances and volume has to reach both.
 */
export class AudioMixer {
  private volumes = new Map<AudioCategory, number>();
  private focused = true;
  private ambienceEnvelope = 1;
  /** Loops (music, ambience) whose volume must follow their channel. */
  private registered = new Map<Howl, PlayableCategory>();
  private cache = new Map<SoundEffect, Howl>();
  private active: ActiveSound[] = [];
  private disposers: (() => void)[] = [];
  private changeListeners = new Set<(category: PlayableCategory) => void>();
  private limiter: DynamicsCompressorNode | null = null;

  constructor(private readonly userSettings: UserSettings) {
    for (const category of [...PLAYABLE, "master" as const]) {
      this.volumes.set(category, this.userSettings.audioVolume(category));
      this.followSetting(category);
    }
    this.followFocus();
    this.applyAll();
    // After applyAll on purpose: Howler builds its AudioContext lazily, and
    // the Howler.volume() write in there is what forces it into existence.
    this.safely("install limiter", () => this.installLimiter());
  }

  /**
   * Splices a limiter between Howler's master gain and the speakers, so a
   * burst of concurrent cues cannot clip.
   *
   * It covers the cue channels and ambience, and -- everywhere streamsMusic()
   * is true -- NOT the music. Howler has no createMediaElementSource anywhere
   * in it, so the only connection into the graph is the Web Audio path and a
   * streamed music Howl plays straight out of its media element past all of
   * this.
   *
   * That gap is acceptable and worth being explicit about rather than letting
   * the name imply otherwise. The music is a mastered stereo bounce already
   * carrying a -1 dB trim and only ever one track plays at a time; the summing
   * risk was always the cue layer, where the per-channel budgets allow up to
   * 16 voices at once with nothing holding the sum down.
   *
   * On iOS the music IS routed through here, because it has to be Web Audio to
   * have a working volume at all. Left alone deliberately: at the default
   * music slider the track peaks around -13 dBFS, far below the -3 dB
   * threshold, so the limiter is transparent. It only engages with the slider
   * near the top, where this bounce's inter-sample peaks (+0.11 and +0.19
   * dBTP) clear the threshold -- and a couple of dB of reduction shared with
   * the cues is the better failure than letting the sum clip.
   *
   * This is not a level control. No make-up gain, and no reduction: headroom
   * is the -2 dB re-bounce's job, this is only for concurrency.
   */
  private installLimiter(): void {
    // Typed non-nullable by @types/howler, but genuinely absent until the
    // context is built and on any device falling back to html5-only audio --
    // no graph to splice into, and nothing to do.
    const ctx = Howler.ctx as AudioContext | undefined;
    const master = Howler.masterGain as GainNode | undefined;
    if (!ctx || !master) return;
    const limiter = ctx.createDynamicsCompressor();
    const now = ctx.currentTime;
    limiter.threshold.setValueAtTime(LIMITER_THRESHOLD_DB, now);
    limiter.knee.setValueAtTime(0, now);
    limiter.ratio.setValueAtTime(LIMITER_RATIO, now);
    limiter.attack.setValueAtTime(LIMITER_ATTACK_S, now);
    limiter.release.setValueAtTime(LIMITER_RELEASE_S, now);
    master.disconnect();
    master.connect(limiter);
    limiter.connect(ctx.destination);
    this.limiter = limiter;
  }

  /** Puts the graph back the way Howler had it, so a later mixer can splice
   * its own limiter in rather than chaining a second one behind this. */
  private removeLimiter(): void {
    const limiter = this.limiter;
    this.limiter = null;
    if (limiter === null) return;
    const ctx = Howler.ctx as AudioContext | undefined;
    const master = Howler.masterGain as GainNode | undefined;
    limiter.disconnect();
    if (!ctx || !master) return;
    master.disconnect();
    master.connect(ctx.destination);
  }

  dispose(): void {
    this.safely("remove limiter", () => this.removeLimiter());
    this.disposers.forEach((off) => off());
    this.disposers = [];
    this.cache.forEach((howl) =>
      this.safely("unload cue", () => howl.unload()),
    );
    this.cache.clear();
    this.registered.clear();
    this.changeListeners.clear();
    this.active = [];
  }

  // ---------------------------------------------------------------- volumes

  /** Final gain for a channel: slider, trim, and the focus duck. */
  volumeFor(category: PlayableCategory): number {
    const slider = perceptualGain(this.volumes.get(category) ?? 0);
    const envelope = category === "ambience" ? this.ambienceEnvelope : 1;
    return (
      slider * CATEGORY_TRIM[category] * this.focusFactor(category) * envelope
    );
  }

  isAudible(category: AudioCategory): boolean {
    if ((this.volumes.get("master") ?? 0) === 0) return false;
    if (category === "master") return true;
    return (this.volumes.get(category) ?? 0) > 0;
  }

  /**
   * Zoom envelope for ambience, 0-1. Kept here rather than on the loop so the
   * value survives a track change mid-zoom.
   */
  setAmbienceEnvelope(gain: number): void {
    const clamped = Math.max(0, Math.min(1, gain));
    if (clamped === this.ambienceEnvelope) return;
    this.ambienceEnvelope = clamped;
    this.applyTo("ambience");
  }

  private focusFactor(category: PlayableCategory): number {
    if (this.focused) return 1;
    if (!this.userSettings.muteOnBlur()) return 1;
    // Alerts are information, not flavour: an inbound nuke should still reach
    // a player who has tabbed away, unless they have said otherwise.
    if (category === "alerts" && this.userSettings.alertsWhenUnfocused()) {
      return 1;
    }
    return 0;
  }

  private applyAll(): void {
    // Master is the one real GainNode Howler exposes; the rest is fan-out.
    this.safely("set master volume", () =>
      Howler.volume(perceptualGain(this.volumes.get("master") ?? 0)),
    );
    for (const category of PLAYABLE) this.applyTo(category);
  }

  /**
   * Notified when a channel's effective volume changes. For loops this class
   * does not own — ambience, which SoundManager crossfades — so they can
   * re-target without the mixer stomping a fade in progress.
   */
  onChange(listener: (category: PlayableCategory) => void): () => void {
    this.changeListeners.add(listener);
    return () => this.changeListeners.delete(listener);
  }

  private applyTo(category: PlayableCategory): void {
    const volume = this.volumeFor(category);
    this.safely(`apply ${category} volume`, () => {
      this.registered.forEach((registeredCategory, howl) => {
        if (registeredCategory === category) howl.volume(volume);
      });
      for (const sound of this.active) {
        if (sound.category === category) sound.howl.volume(volume, sound.id);
      }
    });
    this.changeListeners.forEach((listener) =>
      this.safely("notify volume listener", () => listener(category)),
    );
  }

  private followSetting(category: AudioCategory): void {
    const type = `${USER_SETTINGS_CHANGED_EVENT}:settings.audio.${category}`;
    const handler = (event: Event) => {
      // detail is the serialised value — setCached stores strings.
      const raw = (event as CustomEvent<string>).detail;
      const parsed = typeof raw === "number" ? raw : parseFloat(raw);
      if (isNaN(parsed)) return;
      this.volumes.set(category, parsed);
      if (category === "master") this.applyAll();
      else this.applyTo(category);
    };
    globalThis.addEventListener(type, handler);
    this.disposers.push(() => globalThis.removeEventListener(type, handler));
  }

  private followFocus(): void {
    const update = () => {
      // hasFocus covers alt-tab; hidden covers a backgrounded tab that never
      // fired blur. Recomputed, never counted, so they cannot drift apart.
      const focused = !document.hidden && document.hasFocus();
      if (focused === this.focused) return;
      this.focused = focused;
      this.applyAll();
    };
    for (const type of ["blur", "focus"] as const) {
      globalThis.addEventListener(type, update);
      this.disposers.push(() => globalThis.removeEventListener(type, update));
    }
    document.addEventListener("visibilitychange", update);
    this.disposers.push(() =>
      document.removeEventListener("visibilitychange", update),
    );
  }

  // ------------------------------------------------------------------ loops

  /** Register a looping Howl so its volume follows its channel. */
  register(howl: Howl, category: PlayableCategory): void {
    this.registered.set(howl, category);
    this.safely("set registered volume", () =>
      howl.volume(this.volumeFor(category)),
    );
  }

  unregister(howl: Howl): void {
    this.registered.delete(howl);
  }

  // -------------------------------------------------------------- one-shots

  /** Plays a cue on its own channel, within that channel's budget. */
  play(name: SoundEffect): void {
    // Hegemony: the solo static build ships no audio files — never load one.
    if (ClientEnv.soloStatic()) return;
    const category = categoryOf(name);
    if (!this.isAudible(category)) return;
    this.safely(`play sound ${name}`, () => {
      const inCategory = this.active.filter((s) => s.category === category);
      if (inCategory.length >= BUDGET[category]) {
        if (DROP_NEWEST.has(category)) return;
        const oldest = inCategory[0];
        // Fade from the channel's current level rather than reading it back:
        // Howler's single-argument volume() is a getter only when the value
        // happens to match a sound id, so volume(id) is ambiguous by design.
        const from = this.volumeFor(category);
        if (from === 0) {
          // fade(0, 0, ...) never completes in Howler -- its done check needs
          // from !== to -- so the stop scheduled on "fade" would never run,
          // leaving the cue playing outside its budget with Howler's interval
          // and the listener leaked. A silent channel has nothing to fade.
          oldest.howl.stop(oldest.id);
        } else {
          oldest.howl.fade(from, 0, EVICT_FADE_MS, oldest.id);
          oldest.howl.once(
            "fade",
            () => oldest.howl.stop(oldest.id),
            oldest.id,
          );
        }
        this.forget(oldest.id);
      }

      const howl = this.load(name);
      if (howl === null) return;
      const id = howl.play();
      howl.volume(this.volumeFor(category), id);
      const done = () => this.forget(id);
      this.active.push({ howl, id, category, done });
      this.releaseOnce(howl, id, done);
    });
  }

  /**
   * Plays a channel's representative cue for the settings tab's test buttons.
   * Resolves when it finishes, so the button's disabled state is the pending
   * promise. Resolves immediately when nothing would be heard.
   */
  previewCue(category: CueCategory): Promise<void> {
    if (category === "ambience") {
      // Ambience is a loop with no natural end; the tab previews it through
      // the normal ambience path instead.
      return Promise.resolve();
    }
    const name = PREVIEW_CUE[category];
    if (!this.isAudible(category)) return Promise.resolve();
    return new Promise((resolve) => {
      const howl = this.load(name);
      if (howl === null) {
        resolve();
        return;
      }
      const id = howl.play();
      howl.volume(this.volumeFor(category), id);
      const done = () => {
        this.forget(id);
        resolve();
      };
      this.active.push({ howl, id, category, done });
      this.releaseOnce(howl, id, done);
    });
  }

  /**
   * Runs `done` on whichever of "end"/"stop" reaches this playback id first.
   *
   * Both have to be watched: a cue that runs out fires only "end", while one
   * stopped early (budget eviction, dispose) fires only "stop". Howler's
   * once() drops only the listener for the event that actually fired, so the
   * unfired sibling would otherwise sit on the Howl forever -- and these Howls
   * are cached per cue on a mixer that lives as long as the page, so a cue
   * like "click" would grow its listener list for the whole session. Clearing
   * the sibling here keeps exactly one registration per play.
   */
  private releaseOnce(howl: Howl, id: number, done: () => void): void {
    const release = () => {
      howl.off("end", release, id);
      howl.off("stop", release, id);
      howl.off("playerror", release, id);
      done();
    };
    howl.once("end", release, id);
    howl.once("stop", release, id);
    // A cue that never starts fires neither "end" nor "stop", so without this
    // its entry sits in `active` for the rest of the session and the channel
    // is permanently a voice poorer. Howler emits playerror with the sound's
    // own id, so it matches an id-bound listener like the other two.
    howl.once("playerror", release, id);
  }

  private load(name: SoundEffect): Howl | null {
    const cached = this.cache.get(name);
    if (cached) return cached;
    const src = soundEffectUrls.get(name);
    if (!src) return null;
    try {
      // Silent until play() sets the channel level on the id it is starting.
      // Howler defaults to 1, and on a cue's FIRST play that is audible, not
      // merely untidy: both play() and the volume write queue behind the
      // load, and Howler runs the queued volume from inside a setTimeout
      // after the sound has already started. So the attack of every cue's
      // first play went out at full channel scale regardless of where the
      // player had the slider. Starting from zero turns that into a couple of
      // silent milliseconds instead, which is the better way to be wrong.
      const howl = new Howl({ src: [src], volume: 0 });
      this.cache.set(name, howl);
      // Bound without an id on purpose. Howler emits loaderror with a null id
      // for everything except a media-element error -- no codec, a failed
      // fetch, a failed decode -- and _emit only dispatches to an id-bound
      // listener when the ids match, so an id-bound one would be dead code
      // for exactly the cases that matter.
      howl.once("loaderror", () => this.discard(name, howl));
      return howl;
    } catch (err) {
      console.warn(`AudioMixer: failed to load sound ${name}`, err);
      return null;
    }
  }

  private forget(id: number): void {
    this.active = this.active.filter((s) => s.id !== id);
  }

  /**
   * Writes off a cue whose file would not load.
   *
   * Every entry for the Howl goes at once, because loaderror arrives with no
   * id to match a single playback against, and because none of them can ever
   * fire end or stop to release themselves.
   *
   * It leaves the cache too. Cached, the next play() of this cue would hand
   * back the same dead Howl -- play() on something unloaded queues and
   * returns an id, so it would push another entry nothing can release, and
   * the channel would bleed a voice per attempt until it fell silent.
   *
   * Dropping it means the next play builds a fresh Howl and tries the fetch
   * again. That is deliberate: a blip on the CDN should not silence a cue for
   * the rest of the session, and these files are small. The cost is that a
   * genuinely missing file is re-fetched once per play instead of once, which
   * is wasted work but bounded by how often the cue fires and self-cleaning
   * each time.
   */
  private discard(name: SoundEffect, howl: Howl): void {
    const stranded = this.active.filter((sound) => sound.howl === howl);
    this.active = this.active.filter((sound) => sound.howl !== howl);
    if (this.cache.get(name) === howl) this.cache.delete(name);
    // Settle whatever was waiting on a cue that is now never going to play.
    // Nothing in Howler will do it: a play() queued behind a failed load
    // leaves its Sound with _paused still true, and unload() only stops
    // sounds that are NOT paused -- so it emits no "stop", "end" never comes,
    // and "playerror" needs a play that actually ran. All three of
    // releaseOnce's listeners stay silent for good.
    //
    // Each entry carries its own completion callback, so this does not need
    // to know what any of them are for: previewCue's promise resolves here,
    // and play()'s callback is a no-op because the bookkeeping above has
    // already happened. Before the unload below, so no resolver can be caught
    // by anything that does.
    for (const sound of stranded) {
      this.safely(`settle discarded cue ${name}`, () => sound.done());
    }
    // Bookkeeping first, then unload. A Howl adds itself to Howler._howls on
    // construction and is only ever spliced back out by unload(), so without
    // this the discarded one would sit in that global registry for the life
    // of the page -- unreachable, since it has just left the cache that
    // dispose() walks, and adding work to every Howler.volume() call, which
    // iterates the registry. Retrying the fetch means one more per failed
    // attempt rather than one per cue, so it compounds.
    //
    // Safe to call from inside the loaderror handler: it emits no loaderror
    // of its own, and the listener that brought us here was registered with
    // once() and is already gone, so it cannot re-enter. Any "stop" it does
    // emit dispatches on a timeout and lands after this returns, finding
    // nothing left to forget.
    this.safely(`unload sound ${name}`, () => howl.unload());
  }

  private safely(action: string, fn: () => void): void {
    try {
      fn();
    } catch (err) {
      console.warn(`AudioMixer: failed to ${action}`, err);
    }
  }
}

let instance: AudioMixer | null = null;

/** Created once, from Main.ts, before anything asks to play. */
export function initAudioMixer(userSettings: UserSettings): AudioMixer {
  instance?.dispose();
  // Before the mixer reads a single volume. This is the one place both entry
  // points -- Main.ts on the home page and ClientGameRunner for a game URL
  // opened directly -- go through, so putting the one-time reset here is what
  // makes it run exactly once per page and always ahead of the constructor
  // that caches the values it clears.
  userSettings.resetAudioOnce();
  instance = new AudioMixer(userSettings);
  setCuePlayer((name) => instance?.play(name));
  setAudioControls(instance);
  return instance;
}

/** Null until initAudioMixer runs — component tests mount without it. */
export function audioMixer(): AudioMixer | null {
  return instance;
}

/** Test seam: drops the singleton so each case starts clean. */
export function resetAudioMixerForTest(): void {
  instance?.dispose();
  instance = null;
  setCuePlayer(null);
  setAudioControls(null);
}

export type { AmbienceTrack, CueCategory };
