#!/bin/bash
set -e
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -r "$SRC_DIR/files/." .
echo "applied files:"
cd "$SRC_DIR/files" && find . -type f | sort
