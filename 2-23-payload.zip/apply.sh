#!/bin/bash
# 개선5 diplomacy board payload: copy staged files over the checkout.
set -e
cp -a /tmp/payload/files/. "$GITHUB_WORKSPACE"/
echo "applied: diplomacy board + AI reason notes"
