import { TileRef } from "@openfront/engine-api/game/GameMap";
import {
  BuildableUnit,
  GameType,
  PlayerType,
  Structures,
  UnitType,
} from "@openfront/engine-api/game/GameTypes";
import {
  ErrorUpdate,
  GameUpdateType,
  GameUpdateViewData,
  HashUpdate,
} from "@openfront/engine-api/game/GameUpdates";
import { ClientID, GameID } from "@openfront/engine-api/Schemas";
import { Config } from "@openfront/engine-lib/configuration/Config";
import { TerrainMapData } from "@openfront/engine-lib/game/TerrainMapLoader";
import { findClosestBy } from "@openfront/engine-lib/Util";
import { EventBus } from "@openfront/shared/EventBus";
import { GameMapLoader } from "@openfront/shared/GameMapLoader";
import { replacer } from "@openfront/shared/SharedUtil";
import {
  GameRecord,
  GroupTokenEvent,
  LobbyInfoEvent,
  PlayerCosmeticRefs,
  ServerMessage,
  WireGameStartInfo,
} from "@openfront/shared/WireSchemas";
import { ClientEnv } from "../client/ClientEnv";
import { reloadForUpdate, translateText } from "../client/Utils";
import {
  DelegationZonePickedEvent,
  DelegationZonePickModeEvent,
} from "./DelegationZoneEvents";
import { MapLayerController } from "./controllers/MapLayerController";
import { isDesktopShell } from "./DesktopShell";
import { GameMetrics } from "./GameMetrics";
import { createRenderer, GameRenderer } from "./hud/GameRenderer";
import { goldRateTracker } from "./hud/layers/lib/GoldRateTracker";
import { showInGameAlert } from "./InGameModal";
import {
  AutoUpgradeEvent,
  DoBoatAttackEvent,
  DoBreakAllianceEvent,
  DoGroundAttackEvent,
  DoRequestAllianceEvent,
  DoRetaliateAttackEvent,
  DoTargetPlayerEvent,
  InputHandler,
  MouseMoveEvent,
  MouseUpEvent,
  TickMetricsEvent,
  ToggleRenderDebugGuiEvent,
} from "./InputHandler";
import { rememberLobbyRoster } from "./LobbyRosterLevels";
import { pagePin } from "./PagePin";
import { groupTokenOf, loggableStartMessage } from "./PresenceGroup";
import {
  applyGraphicsOverrides,
  createRenderSettings,
  deepAssign,
  GLUnavailableError,
  MapRenderer,
  preloadAtlasData,
  renderDpr,
  type RenderSettings,
  showGLGate,
  trackGLInit,
} from "./render/gl";
import { ALL_UNIT_TYPES, UnitState } from "./render/types";
import { versionedPathForMismatchedGame } from "./ServerList";
import { audioMixer, initAudioMixer } from "./sound/AudioMixer";
import { SoundManager } from "./sound/SoundManager";
import { reportGameError } from "./Telemetry";
import {
  loadCachedTerrainMap,
  terrainMapFileLoader,
} from "./TerrainMapFileLoader";
import { themeProvider } from "./theme/ThemeProvider";
import { GoToPlayerEvent } from "./TransformHandler";
import {
  counterAttackTroops,
  MoveWarshipIntentEvent,
  NewLobbyEvent,
  SendAllianceExtensionIntentEvent,
  SendAllianceRequestIntentEvent,
  SendAttackIntentEvent,
  SendBoatAttackIntentEvent,
  SendBreakAllianceIntentEvent,
  SendHashEvent,
  SendSpawnIntentEvent,
  SendTargetPlayerIntentEvent,
  SendUpgradeStructureIntentEvent,
  Transport,
} from "./Transport";
import { clampPlanRatio, QueuePlanOrderEvent } from "./WarPlan";
import {
  GRAPHICS_KEY,
  USER_SETTINGS_CHANGED_EVENT,
  UserSettings,
} from "./UserSettings";
import { createCanvas } from "./Utils";
import { GameView, PlayerView } from "./view";
import { WebGLFrameBuilder } from "./WebGLFrameBuilder";
import { WorkerClient } from "./WorkerClient";

export interface LobbyConfig {
  cosmetics: PlayerCosmeticRefs;
  playerName: string;
  playerClanTag: string | null;
  // In-flight clan-tag ownership check; resolves to the tag to submit (null if
  // it failed). Runs parallel to the WS handshake — only the join waits on it.
  clanTagCheck?: Promise<string | null>;
  playerRole: string | null;
  gameID: GameID;
  turnstileToken: string | null;
  // GameStartInfo only exists when playing a singleplayer game.
  gameStartInfo?: WireGameStartInfo;
  // GameRecord exists when replaying an archived game.
  gameRecord?: GameRecord;
  // Watch without playing.
  spectator?: boolean;
  // Host only: the play token the lobby was created under, used for the
  // first join so the host joins as the creator (see createLobby).
  creatorToken?: string;
}

export interface JoinLobbyResult {
  stop: (force?: boolean) => boolean;
  prestart: Promise<void>;
  join: Promise<void>;
}

export function joinLobby(
  eventBus: EventBus,
  lobbyConfig: LobbyConfig,
): JoinLobbyResult {
  // Mutable clientID state — assigned by server (multiplayer) or derived from gameStartInfo (singleplayer)
  let clientID: ClientID | undefined;

  let resolvePrestart: () => void;
  let resolveJoin: () => void;
  const prestartPromise = new Promise<void>((r) => (resolvePrestart = r));
  const joinPromise = new Promise<void>((r) => (resolveJoin = r));

  console.log(`joining lobby: gameID: ${lobbyConfig.gameID}`);

  const userSettings: UserSettings = new UserSettings();
  themeProvider.reset(); // fresh colour allocators for this game
  goldRateTracker.resetAll(); // drop samples from a previous in-page game

  const transport = new Transport(lobbyConfig, eventBus);

  let currentGameRunner: ClientGameRunner | null = null;

  const onconnect = async () => {
    // Drop the tag if the ownership check failed; the server re-checks anyway.
    if (lobbyConfig.clanTagCheck !== undefined) {
      lobbyConfig.playerClanTag = await lobbyConfig.clanTagCheck;
    }
    // Always send join - server will detect reconnection via persistentID
    console.log(`Joining game lobby ${lobbyConfig.gameID}`);
    transport.joinGame();
  };
  // Only begin a terrain preload once the same map has been stable across
  // this many consecutive lobby_info broadcasts (one per second). A host
  // clicking through map selections changes the config every broadcast, so
  // debouncing avoids downloading (and permanently caching) a map that was
  // only shown transiently.
  const MAP_PRELOAD_DEBOUNCE_STREAK = 3;
  // In-flight terrain loads keyed by `map:mapSize`, so re-requesting a map
  // that began loading earlier (even after another map superseded it) reuses
  // the original promise instead of starting a duplicate download/parse while
  // the first one is still running.
  const terrainLoads = new Map<string, Promise<TerrainMapData>>();
  // The load the authoritative start gate consumes (createClientGame) — always
  // the most recent request; dedup makes it the map that actually starts.
  let terrainLoad: Promise<TerrainMapData> | null = null;
  // Map key (map:mapSize) most recently seen in lobby_info and how many
  // consecutive broadcasts it has held. The preload is only triggered once
  // the streak reaches the debounce threshold.
  let pendingPreloadKey: string | null = null;
  let pendingPreloadStreak = 0;
  const requestTerrainLoad = (
    map: Parameters<typeof loadCachedTerrainMap>[0],
    mapSize: Parameters<typeof loadCachedTerrainMap>[1],
  ): Promise<TerrainMapData> => {
    const key = `${map}:${mapSize}`;
    const existing = terrainLoads.get(key);
    if (existing !== undefined) {
      terrainLoad = existing;
      return existing;
    }
    const load = loadCachedTerrainMap(map, mapSize);
    terrainLoads.set(key, load);
    terrainLoad = load;
    void load.catch((e) => {
      // Clear a failed load so the authoritative start gate can retry.
      if (terrainLoads.get(key) === load) {
        terrainLoads.delete(key);
      }
      if (terrainLoad === load) {
        terrainLoad = null;
      }
      // If this map is the one the debounce points at, reset its streak so a
      // persistent failure doesn't re-trigger (and warn-spam) on every
      // subsequent lobby_info broadcast; a transient blip just re-accumulates.
      if (pendingPreloadKey === key) {
        pendingPreloadKey = null;
        pendingPreloadStreak = 0;
      }
      console.warn(
        `lobby: terrain preload failed for "${key}"; will retry at game start`,
        e,
      );
    });
    return load;
  };

  const onmessage = (message: ServerMessage) => {
    // Before the per-type handling below: the token rides two different
    // messages and the listener does not care which one delivered it.
    const groupToken = groupTokenOf(message);
    if (groupToken !== undefined) {
      eventBus.emit(new GroupTokenEvent(groupToken));
    }
    if (message.type === "lobby_info") {
      // Server tells us our assigned clientID
      clientID = message.myClientID;
      eventBus.emit(new LobbyInfoEvent(message.lobby, message.myClientID));
      // Kept past game start for the in-game level badges.
      rememberLobbyRoster(
        message.lobby.gameID,
        message.lobby.clients,
        message.myClientID,
      );
      // Preload the map while still in the lobby so game start can reuse the
      // cached result instead of blocking on the download in the short
      // prestart->start window. The preload is debounced: it only fires once
      // the same map has held across several broadcasts, so a host clicking
      // through map selections doesn't trigger a download (which would be
      // permanently cached) for each transient pick. requestTerrainLoad
      // deduplicates in-flight loads, and prestart still re-validates the
      // authoritative map.
      const gameConfig = message.lobby.gameConfig;
      if (gameConfig === undefined) {
        // No config in this broadcast — reset the debounce so a stale key /
        // streak can't prematurely trigger a preload on a later matching one.
        pendingPreloadKey = null;
        pendingPreloadStreak = 0;
      } else {
        const key = `${gameConfig.gameMap}:${gameConfig.gameMapSize}`;
        if (pendingPreloadKey === key) {
          pendingPreloadStreak++;
        } else {
          pendingPreloadKey = key;
          pendingPreloadStreak = 1;
        }
        if (pendingPreloadStreak >= MAP_PRELOAD_DEBOUNCE_STREAK) {
          requestTerrainLoad(gameConfig.gameMap, gameConfig.gameMapSize);
        }
      }
      return;
    }
    if (message.type === "prestart") {
      console.log(
        `lobby: game prestarting: ${JSON.stringify(message, replacer)}`,
      );
      requestTerrainLoad(message.gameMap, message.gameMapSize);
      resolvePrestart();
    }
    if (message.type === "start") {
      // Trigger prestart for singleplayer games
      resolvePrestart();
      // Everything in the start message EXCEPT the group token. This log is
      // the whole message verbatim and players paste it into bug reports;
      // the token is the one field in it that must not travel that way.
      console.log(
        `lobby: game started: ${JSON.stringify(
          loggableStartMessage(message),
          replacer,
          2,
        )}`,
      );
      // Server tells us our assigned clientID (also sent on start for late joins)
      clientID = message.myClientID;
      resolveJoin();
      // For multiplayer games, GameStartInfo is not known until game starts.
      lobbyConfig.gameStartInfo = message.gameStartInfo;
      createClientGame(
        lobbyConfig,
        clientID,
        eventBus,
        transport,
        userSettings,
        terrainLoad,
        terrainMapFileLoader,
      )
        .then((r) => {
          currentGameRunner = r;
          r.start();
        })
        .catch((e) => {
          console.error("error creating client game", e);

          currentGameRunner = null;

          const startingModal = document.querySelector(
            "game-starting-modal",
          ) as HTMLElement;
          if (startingModal) {
            startingModal.classList.add("hidden");
          }
          // No GPU-accelerated WebGL2: gate with an actionable message rather
          // than the generic crash modal (the game would crawl at ~1fps).
          if (e instanceof GLUnavailableError) {
            showGLGate(e.glStatus);
            return;
          }
          showErrorModal(
            e.message,
            e.stack,
            lobbyConfig.gameID,
            clientID,
            true,
            false,
            "error_modal.connection_error",
          );
        });
    }
    if (message.type === "error") {
      if (message.error === "full-lobby" || message.error === "game-started") {
        document.dispatchEvent(
          new CustomEvent("leave-lobby", {
            detail: { lobby: lobbyConfig.gameID, cause: message.error },
            bubbles: true,
            composed: true,
          }),
        );
      } else if (message.error === "kick_reason.host_left") {
        showInGameAlert(translateText("kick_reason.host_left")).then(() => {
          document.dispatchEvent(
            new CustomEvent("leave-lobby", {
              detail: { lobby: lobbyConfig.gameID, cause: "host-left" },
              bubbles: true,
              composed: true,
            }),
          );
        });
      } else if (message.error === "kick_reason.match_cancelled") {
        // A matched player never connected and the server cancelled the game
        // pre-start. Tear down the dead lobby, then put the matchmaking
        // modal — still open on "waiting for game" (it only closes at
        // prestart) — straight back into the queue so the players who did
        // connect don't have to requeue by hand. A non-blocking toast
        // explains why; an alert here would keep them out of the queue
        // until dismissed.
        document.dispatchEvent(
          new CustomEvent("leave-lobby", {
            detail: { lobby: lobbyConfig.gameID, cause: "match-cancelled" },
            bubbles: true,
            composed: true,
          }),
        );
        document.dispatchEvent(new CustomEvent("matchmaking-requeue"));
        window.dispatchEvent(
          new CustomEvent("show-message", {
            detail: {
              message: translateText("kick_reason.match_cancelled"),
              color: "red",
              duration: 5000,
            },
          }),
        );
      } else if (message.error === "version_mismatch") {
        console.info(
          `version mismatch: bundle ${ClientEnv.gitCommit()}, server ${message.gitCommit}`,
        );
        // The game's server runs a different build than this bundle. On the
        // desktop the shell updates its local overlay itself, so just say
        // what's happening and let its update bar take it from there.
        //
        // On the web, in order: this host's own `/v/<commit>/` page, which
        // keeps the loaded document and the Turnstile token; else the
        // game's host, whose shell serves the matching bundle (and map);
        // else this tab is simply stale (left open across a deploy), so
        // reload. See docs/MultiServer.md (OPE-471).
        if (isDesktopShell()) {
          void showInGameAlert(translateText("update_available.desktop"));
        } else {
          const versioned = versionedPathForMismatchedGame(
            lobbyConfig.gameID,
            message.gitCommit,
          );
          const r = ClientEnv.resolveGame(lobbyConfig.gameID);
          if (versioned !== null) {
            window.location.href = versioned;
          } else if (r.kind === "cross") {
            window.location.href = `https://${r.host}/game/${lobbyConfig.gameID}${window.location.search}`;
          } else if (pagePin() !== null) {
            // A pinned `/v/<commit>/` page must not reload. The pin comes
            // from PagePin (captured at boot), not from the live pathname:
            // updateJoinUrlForShare has already rewritten the address bar to
            // the version-free share URL by the time any mismatch can
            // arrive, and reading it here would take the branch below.
            // reloadForUpdate
            // strips the pin — right for an ordinary stale tab, fatal here:
            // it lands on `latest`, whose handleUrl sees this same game on
            // this same older server and pins the page straight back, one
            // lap per click. Nothing this page can fetch is the build it
            // needs (that is what a mismatch on a pinned page MEANS: the
            // version's page is not being served), so say so and stop.
            void showInGameAlert(translateText("update_available.message"));
          } else {
            showInGameAlert(translateText("update_available.message")).then(
              () => {
                reloadForUpdate();
              },
            );
          }
        }
      } else {
        showErrorModal(
          message.error,
          message.message,
          lobbyConfig.gameID,
          clientID,
          true,
          false,
          "error_modal.connection_error",
        );
      }
    }
  };
  transport.connect(onconnect, onmessage);
  return {
    stop: (force: boolean = false) => {
      if (!force && currentGameRunner?.shouldPreventWindowClose()) {
        console.log("Player is active, prevent leaving game");
        return false;
      }
      console.log("leaving game");
      if (currentGameRunner) {
        currentGameRunner.stop();
        currentGameRunner = null;
      } else {
        transport.leaveGame();
      }
      return true;
    },
    prestart: prestartPromise,
    join: joinPromise,
  };
}

// Build the WebGL view + its glCanvas. Must run before createRenderer so the
// controllers can be wired directly to the view.
function createWebGLView(
  terrainMap: TerrainMapData,
  config: Config,
  settings: RenderSettings,
): {
  view: MapRenderer;
  glCanvas: HTMLCanvasElement;
  cachedWebGLFrameCallback: { current: FrameRequestCallback | null };
} {
  const gameMap = terrainMap.gameMap;
  const mapWidth = gameMap.width();
  const mapHeight = gameMap.height();

  // Provider, not a buffer: per-tile terrain bytes are map-sized (8 MB on
  // the giant map), so consumers regenerate them on demand (initial bake,
  // context restore, theme change) instead of anyone retaining a copy.
  // gameMap is updated live by water-nuke conversions, so a regenerated
  // array always reflects them.
  const terrainSource = (): Uint8Array => {
    const terrainBytes = new Uint8Array(mapWidth * mapHeight);
    for (let y = 0; y < mapHeight; y++) {
      for (let x = 0; x < mapWidth; x++) {
        terrainBytes[y * mapWidth + x] = gameMap.terrainByte(gameMap.ref(x, y));
      }
    }
    return terrainBytes;
  };

  const glCanvas = createCanvas();
  glCanvas.id = "webgl-debug-canvas";
  glCanvas.style.pointerEvents = "none";
  document.body.insertBefore(glCanvas, document.body.firstChild);

  // Capture the WebGL renderer's animation-frame callback rather than letting
  // it run its own RAF loop. Two independent RAF loops race: when the user
  // pans, the WebGL renderer can draw with one-frame-stale camera state
  // because its RAF fires before canvas2D's RAF (which would have synced the
  // camera). Driving WebGL's draw synchronously from canvas2D's onPreRender
  // hook locks them to the same frame.
  const cachedWebGLFrameCallback: { current: FrameRequestCallback | null } = {
    current: null,
  };
  const captureRaf = (cb: FrameRequestCallback): number => {
    cachedWebGLFrameCallback.current = cb;
    return 0;
  };
  const captureCaf = (_id: number): void => {
    cachedWebGLFrameCallback.current = null;
  };

  const palette = new Float32Array(4096 * 2 * 4);
  // Log the GPU init result on every session so we can size the real % of
  // users on software/missing WebGL2. MapRenderer constructs the GL context;
  // a non-accelerated context throws GLUnavailableError (handled by the
  // game-start catch, which shows the gate).
  let view: MapRenderer;
  try {
    view = new MapRenderer(
      glCanvas,
      {
        mapWidth,
        mapHeight,
        unitTypes: [...ALL_UNIT_TYPES],
        players: [],
        // Pre-allocate renderer textures for up to 1024 players. We add players
        // dynamically via view.addPlayers() as they come in from the simulation,
        // but the NamePass / palette / relation matrix all need a static upper
        // bound at construction time.
        maxPlayers: 1024,
      },
      terrainSource,
      palette,
      config,
      settings,
      captureRaf,
      captureCaf,
    );
  } catch (e) {
    if (e instanceof GLUnavailableError) {
      trackGLInit(e.glStatus, e.renderer);
    }
    // The renderer never took ownership of the canvas, so remove it here —
    // otherwise it lingers in the DOM holding a (possibly software) GL context.
    glCanvas.remove();
    throw e;
  }
  // Fingerprint-capped context (#4357): the game runs, but the map may render
  // with black areas. Warn with fix instructions; the player can continue.
  if (view.glLimited) {
    trackGLInit(
      "limited",
      view.glLimited.renderer,
      view.glLimited.maxTextureSize,
    );
    showGLGate("limited");
  } else {
    trackGLInit("ok", "");
  }

  (window as unknown as { __webglView?: unknown }).__webglView = view;

  return { view, glCanvas, cachedWebGLFrameCallback };
}

function mountWebGLFrameLoop(
  terrainMap: TerrainMapData,
  view: MapRenderer,
  glCanvas: HTMLCanvasElement,
  cachedWebGLFrameCallback: { current: FrameRequestCallback | null },
  transformHandler: import("./TransformHandler").TransformHandler,
  gameView: GameView,
  eventBus: EventBus,
  onFrame: (nowMs: number) => void,
): { builder: WebGLFrameBuilder; stopFrameLoop: () => void } {
  const gameMap = terrainMap.gameMap;
  const mapWidth = gameMap.width();
  const mapHeight = gameMap.height();

  // Cache canvas dimensions to avoid forced reflows every frame. Reading
  // clientWidth/clientHeight flushes pending layout — at 60fps that's a
  // measurable cost. Only update on resize events from the observer.
  let cachedCanvasW = glCanvas.clientWidth;
  let cachedCanvasH = glCanvas.clientHeight;
  const resizeObs = new ResizeObserver((entries) => {
    for (const entry of entries) {
      const { width, height } = entry.contentRect;
      if (width > 0 && height > 0) {
        cachedCanvasW = width;
        cachedCanvasH = height;
      }
    }
  });
  resizeObs.observe(glCanvas);

  const syncCamera = (): void => {
    const scale = transformHandler.scale;
    const dpr = renderDpr();
    const centerX =
      transformHandler.offsetX +
      mapWidth / 2 +
      (cachedCanvasW - mapWidth) / (2 * scale);
    const centerY =
      transformHandler.offsetY +
      mapHeight / 2 +
      (cachedCanvasH - mapHeight) / (2 * scale);
    view.setCameraState(centerX, centerY, scale * dpr);
    // Invoke the WebGL renderer's frame callback synchronously, with the just-
    // updated camera state. The callback re-arms itself via captureRaf, so
    // we'll get a fresh callback ready for the next canvas2D frame.
    const cb = cachedWebGLFrameCallback.current;
    cachedWebGLFrameCallback.current = null;
    cb?.(performance.now());
  };

  // Move-target chevrons: when the player issues a warship move, show the
  // animated chevron pass at the target tile. The renderer needs the target's
  // tile x/y and the warship's owner smallID (so the chevrons use the right
  // color).
  eventBus.on(MoveWarshipIntentEvent, (e) => {
    const tile = e.tile;
    const tx = gameView.x(tile);
    const ty = gameView.y(tile);
    // Resolve owner via the first unit in the move set.
    const firstUnit = gameView.unit(e.unitIds[0]);
    if (firstUnit === undefined) return;
    view.showMoveIndicator(tx, ty, firstUnit.owner().smallID());
  });

  // Self-driving RAF: syncCamera reads the latest camera state from
  // TransformHandler, pushes it to WebGL, and synchronously invokes the
  // renderer's captured frame callback (which draws). One RAF = one
  // synchronized camera-update + WebGL render.
  let rafId: number | null = null;
  const driveFrame = (nowMs: number): void => {
    onFrame(nowMs);
    syncCamera();
    rafId = requestAnimationFrame(driveFrame);
  };
  rafId = requestAnimationFrame(driveFrame);

  // Tear down the per-frame loop so a stopped game stops driving WebGL and
  // releases the view for disposal. Left running, the RAF keeps the WebGL
  // context referenced (and alive) forever — each new game would then stack
  // another context until the browser's limit is hit.
  const stopFrameLoop = (): void => {
    if (rafId !== null) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }
    resizeObs.disconnect();
  };

  const builder = new WebGLFrameBuilder(view);

  // When context is lost and restored, WebGL loses all textures and geometry.
  // Force a full re-upload of the simulation state.
  view.onContextRestored = () => {
    builder.clearCaches();

    // Full upload of terrain, territory & trail state
    const mapSize = mapWidth * mapHeight;
    const allTerrain = new Uint8Array(mapSize);
    for (let i = 0; i < mapSize; i++) {
      allTerrain[i] = gameView.terrainByte(i);
    }
    view.applyTerrainRects(
      [{ x: 0, y: 0, w: mapWidth, h: mapHeight }],
      allTerrain,
    );

    const frameData = gameView.frameData();
    view.uploadTileAndTrailState(frameData.tileState, frameData.trailState);

    // Structures, railroads and relations normally skip GPU upload unless
    // marked dirty, now force
    view.updateStructures(frameData.units as Map<number, UnitState>);
    view.uploadRailroadState(frameData.railroadState);
    view.updateRelations(frameData.relationMatrix, frameData.relationSize);

    builder.update(gameView);
  };

  return { builder, stopFrameLoop };
}

async function createClientGame(
  lobbyConfig: LobbyConfig,
  clientID: ClientID | undefined,
  eventBus: EventBus,
  transport: Transport,
  userSettings: UserSettings,
  terrainLoad: Promise<TerrainMapData> | null,
  mapLoader: GameMapLoader,
): Promise<ClientGameRunner> {
  if (lobbyConfig.gameStartInfo === undefined) {
    throw new Error("missing gameStartInfo");
  }
  const config = new Config(
    lobbyConfig.gameStartInfo.config,
    lobbyConfig.gameRecord !== undefined,
    lobbyConfig.gameStartInfo.listed,
    lobbyConfig.spectator === true,
  );
  let gameMap: TerrainMapData;

  if (terrainLoad) {
    gameMap = await terrainLoad;
  } else {
    gameMap = await loadCachedTerrainMap(
      lobbyConfig.gameStartInfo.config.gameMap,
      lobbyConfig.gameStartInfo.config.gameMapSize,
    );
  }
  // Kick off the font-atlas fetch so it overlaps with worker init; the
  // render passes need it parsed before createWebGLView runs.
  const atlasDataLoad = preloadAtlasData();
  const worker = new WorkerClient(lobbyConfig.gameStartInfo, clientID);
  await worker.initialize();
  await atlasDataLoad;
  const gameView = new GameView(
    worker,
    config,
    gameMap,
    clientID,
    lobbyConfig.playerName,
    lobbyConfig.playerClanTag,
    lobbyConfig.gameStartInfo.gameID,
    lobbyConfig.gameStartInfo.players,
  );

  // Transparent fullscreen overlay used purely as the pointer-event /
  // bounding-rect target for InputHandler + TransformHandler. The actual
  // map drawing happens on the WebGL canvas created in createWebGLView.
  const inputOverlay = document.createElement("div");
  inputOverlay.id = "game-input-overlay";
  inputOverlay.style.position = "fixed";
  inputOverlay.style.left = "0";
  inputOverlay.style.top = "0";
  inputOverlay.style.width = "100%";
  inputOverlay.style.height = "100%";
  inputOverlay.style.touchAction = "none";
  document.body.appendChild(inputOverlay);

  // Main.ts creates the mixer on page load; fall back for entry points that
  // start a game without it (tests, embedded shells).
  const soundManager = new SoundManager(
    eventBus,
    audioMixer() ?? initAudioMixer(userSettings),
  );
  try {
    // Resolve render settings (defaults + user overrides) up front so the
    // renderer is built with the final values — no construct-with-defaults,
    // re-apply-overrides dance, and texture-baking passes (terrain) get the
    // right colors on the first build.
    const resolveRenderSettings = (): RenderSettings => {
      const settings = createRenderSettings();
      applyGraphicsOverrides(settings, userSettings.graphicsOverrides());
      return settings;
    };

    const { view, glCanvas, cachedWebGLFrameCallback } = createWebGLView(
      gameMap,
      config,
      resolveRenderSettings(),
    );

    const graphicsListenerAbort = new AbortController();

    const mapLayerController = new MapLayerController(
      view,
      gameMap,
      userSettings,
      lobbyConfig.gameStartInfo.config.gameMap,
      lobbyConfig.gameStartInfo.config.gameMapSize,
      mapLoader,
      graphicsListenerAbort.signal,
    );

    // Re-resolve names drawn on the map when the anonymous-names setting toggles
    // so they switch live, like the leaderboard.
    globalThis.addEventListener(
      `${USER_SETTINGS_CHANGED_EVENT}:settings.anonymousNames`,
      () => {
        webglBuilder.refreshNames(gameView);
        gameView.invalidateTeamClanTags();
      },
      { signal: graphicsListenerAbort.signal },
    );

    // Re-resolve settings and copy them onto the renderer's live object in
    // place (passes hold a reference to it, so they pick the change up).
    const regenerateRenderSettings = (): void => {
      deepAssign(view.getSettings(), resolveRenderSettings());
    };
    // Rebuild the GPU-derived graphics state that the per-frame passes don't
    // pick up from the live settings object on their own.
    const refreshDerivedGraphics = (): void => {
      // Terrain is baked into a GPU texture rather than read per-frame, so a
      // terrain-color override (e.g. ocean) needs an explicit texture rebuild.
      view.rebuildTerrain();
      // A graphics override can switch the active theme (e.g. colorblind mode),
      // so re-theme existing players and re-upload the palette to recolor their
      // territory fills/borders live.
      gameView.refreshPlayerColors();
      webglBuilder.refreshPalette(gameView);
    };
    // Re-apply render settings, then re-theme and recolor players, on a
    // graphics-override change (covers a theme switch such as colorblind mode).
    // Flag opacity is a render setting, not visibility, so it's left out.
    const cosmeticVisibilityKey = (): string =>
      JSON.stringify({
        ...userSettings.graphicsOverrides().cosmetics,
        flagOpacity: undefined,
      });
    let cosmeticVisibility = cosmeticVisibilityKey();
    const onGraphicsChanged = (): void => {
      regenerateRenderSettings();
      refreshDerivedGraphics();
      // Re-resolving every player's cosmetics is heavier than the rest, so
      // only do it when the cosmetics visibility itself changed.
      const nextCosmeticVisibility = cosmeticVisibilityKey();
      if (nextCosmeticVisibility !== cosmeticVisibility) {
        cosmeticVisibility = nextCosmeticVisibility;
        webglBuilder.refreshCosmetics(gameView);
      }
    };
    // No initial regenerate or terrain rebuild needed — the renderer was
    // constructed with the resolved settings above, so the terrain texture
    // already bakes any saved ocean-color override.
    globalThis.addEventListener(
      `${USER_SETTINGS_CHANGED_EVENT}:${GRAPHICS_KEY}`,
      onGraphicsChanged,
      { signal: graphicsListenerAbort.signal },
    );

    // Loaded on demand so lil-gui and the debug GUI stay out of the main bundle.
    // Two folders: "Effect Editor" and "Render Settings".
    let debugGui: { open(): void; destroy(): void } | null = null;
    let debugGuiLoading = false;
    eventBus.on(ToggleRenderDebugGuiEvent, () => {
      if (debugGui === null) {
        if (debugGuiLoading) return;
        debugGuiLoading = true;
        import("./render/gl/debug/index")
          .then(({ createDebugGui }) => {
            debugGui = createDebugGui(
              view.getSettings(),
              {
                setOverride: (effectType, attrs) =>
                  webglBuilder.setEffectOverride(effectType, attrs),
              },
              resolveRenderSettings,
              refreshDerivedGraphics,
            );
            debugGui.open();
          })
          .finally(() => {
            debugGuiLoading = false;
          });
      } else {
        debugGui.destroy();
        debugGui = null;
      }
    });

    const gameRenderer = createRenderer(
      inputOverlay,
      gameView,
      eventBus,
      lobbyConfig.playerRole,
      view,
      mapLayerController,
    );

    const metrics = new GameMetrics(lobbyConfig.gameID, clientID);
    const { builder: webglBuilder, stopFrameLoop } = mountWebGLFrameLoop(
      gameMap,
      view,
      glCanvas,
      cachedWebGLFrameCallback,
      gameRenderer.transformHandler,
      gameView,
      eventBus,
      (nowMs) => metrics.recordFrame(nowMs),
    );

    // Releases all WebGL/DOM resources this game created. Without it, stopping
    // a game (e.g. joining another without a page reload) leaks the WebGL
    // context, canvas and input overlay — a few games and mobile browsers hit
    // their WebGL context limit. Idempotent: stop() may be called more than once.
    let rendererDisposed = false;
    const disposeRenderer = (): void => {
      if (rendererDisposed) return;
      rendererDisposed = true;
      stopFrameLoop();
      view.dispose();
      glCanvas.remove();
      inputOverlay.remove();
    };

    console.log(
      `creating private game got difficulty: ${lobbyConfig.gameStartInfo.config.difficulty}`,
    );

    return new ClientGameRunner(
      lobbyConfig,
      clientID,
      eventBus,
      gameRenderer,
      new InputHandler(gameView, gameRenderer.uiState, inputOverlay, eventBus),
      transport,
      worker,
      gameView,
      soundManager,
      userSettings,
      webglBuilder,
      graphicsListenerAbort,
      disposeRenderer,
      metrics,
    );
  } catch (err) {
    soundManager.dispose();
    throw err;
  }
}

export class ClientGameRunner {
  private trailingTickTimer: ReturnType<typeof setTimeout> | undefined;
  private myPlayer: PlayerView | null = null;
  private isActive = false;

  private turnsSeen = 0;
  // True from a (re)join request until the server's start message answers it.
  // Live turns that land in that window arrive ahead of turnsSeen and are
  // dropped; the start message replays them, so dropping them is expected.
  private awaitingStart = true;
  private lastMousePosition: { x: number; y: number } | null = null;

  private lastMessageTime: number = 0;
  private connectionCheckInterval: NodeJS.Timeout | null = null;
  private goToPlayerTimeout: NodeJS.Timeout | null = null;

  private lastTickReceiveTime: number = 0;
  private currentTickDelay: number | undefined = undefined;

  constructor(
    private lobby: LobbyConfig,
    private clientID: ClientID | undefined,
    private eventBus: EventBus,
    private renderer: GameRenderer,
    private input: InputHandler,
    private transport: Transport,
    private worker: WorkerClient,
    private gameView: GameView,
    private soundManager: SoundManager,
    private userSettings: UserSettings,
    private webglBuilder: WebGLFrameBuilder | null = null,
    private graphicsListenerAbort: AbortController | null = null,
    private disposeRenderer: (() => void) | null = null,
    private metrics: GameMetrics | null = null,
  ) {
    this.lastMessageTime = Date.now();
  }

  /**
   * Determines whether window closing should be prevented.
   *
   * Used to show a confirmation dialog when the user attempts to close
   * the window or navigate away during an active game session.
   *
   * @returns {boolean} `true` if the window close should be prevented
   * (when the player is alive in the game), `false` otherwise
   * (when the player is not alive or doesn't exist)
   */
  public shouldPreventWindowClose(): boolean {
    // Show confirmation dialog if player is alive in the game
    return !!this.myPlayer?.isAlive();
  }

  public start() {
    this.soundManager.playBackgroundMusic();
    console.log("starting client game");

    this.isActive = true;
    this.lastMessageTime = Date.now();
    this.metrics?.start();
    setTimeout(() => {
      this.connectionCheckInterval = setInterval(
        () => this.onConnectionCheck(),
        1000,
      );
    }, 20000);

    this.eventBus.on(MouseUpEvent, this.inputEvent.bind(this));
    // 개선 9: while the delegation panel is in zone-pick mode, the next map
    // click chooses the protected-zone center instead of attacking.
    this.eventBus.on(DelegationZonePickModeEvent, (e) => {
      this.delegationZonePick = e.active;
    });
    this.eventBus.on(MouseMoveEvent, this.onMouseMove.bind(this));
    this.eventBus.on(AutoUpgradeEvent, this.autoUpgradeEvent.bind(this));
    this.eventBus.on(
      DoBoatAttackEvent,
      this.doBoatAttackUnderCursor.bind(this),
    );
    this.eventBus.on(
      DoGroundAttackEvent,
      this.doGroundAttackUnderCursor.bind(this),
    );
    this.eventBus.on(
      DoRetaliateAttackEvent,
      this.doRetaliateAttackMostRecent.bind(this),
    );
    this.eventBus.on(
      DoRequestAllianceEvent,
      this.doRequestAllianceUnderCursor.bind(this),
    );
    this.eventBus.on(
      DoBreakAllianceEvent,
      this.doBreakAllianceUnderCursor.bind(this),
    );
    this.eventBus.on(
      DoTargetPlayerEvent,
      this.doTargetPlayerUnderCursor.bind(this),
    );

    this.renderer.initialize();
    this.input.initialize();
    this.worker.start((gu: GameUpdateViewData | ErrorUpdate) => {
      if (this.lobby.gameStartInfo === undefined) {
        throw new Error("missing gameStartInfo");
      }
      if ("errMsg" in gu) {
        showErrorModal(
          gu.errMsg,
          gu.stack ?? "missing",
          this.lobby.gameStartInfo.gameID,
          this.clientID,
        );
        console.error(gu.stack);
        this.stop();
        return;
      }
      this.transport.turnComplete();
      gu.updates[GameUpdateType.Hash].forEach((hu: HashUpdate) => {
        this.eventBus.emit(new SendHashEvent(hu.tick, hu.hash));
      });
      this.gameView.update(gu);
      this.webglBuilder?.update(this.gameView);
      this.renderer.tick();
      // 레이어 tick은 간격 제한이 있어, 따라잡기·일시정지 직전의 마지막 업데이트가
      // 제한에 걸리면 시계·순위표가 몇 초 전 값으로 멈춘다. 새 업데이트가 한동안
      // 없으면(정지) 마지막 상태로 한 번 더 그려 맞춘다.
      if (this.trailingTickTimer !== undefined) {
        clearTimeout(this.trailingTickTimer);
      }
      this.trailingTickTimer = setTimeout(() => {
        this.trailingTickTimer = undefined;
        this.renderer.tick();
      }, 1100);
      if (gu.tickExecutionDuration !== undefined) {
        this.metrics?.recordTickExecution(gu.tickExecutionDuration);
      }

      // Emit tick metrics event for performance overlay
      this.eventBus.emit(
        new TickMetricsEvent(gu.tickExecutionDuration, this.currentTickDelay),
      );

      // Reset tick delay for next measurement
      this.currentTickDelay = undefined;
    });

    const onconnect = () => {
      console.log("Connected to game server!");
      this.awaitingStart = true;
      this.transport.rejoinGame(this.turnsSeen);
    };

    let hasGoneToPlayer = false;
    const onmessage = (message: ServerMessage) => {
      this.lastMessageTime = Date.now();
      if (message.type === "start") {
        console.log("starting game! in client game runner");
        this.awaitingStart = false;

        if (this.gameView.config().isRandomSpawn()) {
          const goToPlayer = () => {
            const myPlayer = this.gameView.myPlayer();

            if (this.gameView.inSpawnPhase() && !myPlayer?.hasSpawned()) {
              this.goToPlayerTimeout = setTimeout(goToPlayer, 1000);
              return;
            }

            if (!myPlayer) {
              return;
            }

            if (!this.gameView.inSpawnPhase() && !myPlayer.hasSpawned()) {
              showErrorModal(
                "spawn_failed",
                translateText("error_modal.spawn_failed.description"),
                this.lobby.gameID,
                this.clientID,
                true,
                false,
                "error_modal.spawn_failed.title",
              );
              return;
            }

            this.eventBus.emit(new GoToPlayerEvent(myPlayer, 10));
          };

          goToPlayer();
        }

        for (const turn of message.turns) {
          if (turn.turnNumber < this.turnsSeen) {
            continue;
          }
          while (turn.turnNumber - 1 > this.turnsSeen) {
            this.worker.sendTurn({
              turnNumber: this.turnsSeen,
              intents: [],
            });
            this.turnsSeen++;
          }
          this.worker.sendTurn(turn);
          this.turnsSeen++;
        }
      }
      if (message.type === "desync") {
        if (this.lobby.gameStartInfo === undefined) {
          throw new Error("missing gameStartInfo");
        }
        showErrorModal(
          `desync from server: ${JSON.stringify(message)}`,
          "",
          this.lobby.gameStartInfo.gameID,
          this.clientID,
          true,
          false,
          "error_modal.desync_notice",
        );
      }
      if (message.type === "error") {
        showErrorModal(
          message.error,
          message.message,
          this.lobby.gameID,
          this.clientID,
          true,
          false,
          "error_modal.connection_error",
        );
      }
      if (message.type === "pong") {
        this.metrics?.recordRoundTrip(
          Math.floor(performance.now()) - message.sentAt,
        );
      }
      if (message.type === "new_lobby") {
        // The host reused this private lobby: surface the successor id so the
        // group can hop over. NewLobbyPrompt navigates the host and prompts
        // everyone else.
        this.eventBus.emit(new NewLobbyEvent(message.gameID));
      }
      if (message.type === "turn") {
        if (
          !this.gameView.inSpawnPhase() &&
          !hasGoneToPlayer &&
          this.gameView.myPlayer() &&
          this.userSettings.goToPlayer()
        ) {
          hasGoneToPlayer = true;
          this.eventBus.emit(new GoToPlayerEvent(this.gameView.myPlayer()!, 8));
        }

        // Track when we receive the turn to calculate delay
        const now = Date.now();
        if (this.lastTickReceiveTime > 0) {
          // Calculate delay between receiving turn messages
          this.currentTickDelay = now - this.lastTickReceiveTime;
          // Only the wire is worth measuring; a local game paces itself.
          if (!this.transport.isLocal) {
            this.metrics?.recordTickInterval(this.currentTickDelay);
          }
        }
        this.lastTickReceiveTime = now;

        if (this.turnsSeen !== message.turn.turnNumber) {
          // Expected while the start message is still on its way (every
          // multiplayer game start hits this); an error once it has arrived.
          (this.awaitingStart ? console.debug : console.error)(
            `got wrong turn have turns ${this.turnsSeen}, received turn ${message.turn.turnNumber}`,
          );
        } else {
          this.worker.sendTurn(
            // Filter out pause intents in replays
            this.gameView.config().isReplay()
              ? {
                  ...message.turn,
                  intents: message.turn.intents.filter(
                    (i) => i.type !== "toggle_pause",
                  ),
                }
              : message.turn,
          );
          this.turnsSeen++;
        }
      }
    };
    this.transport.updateCallback(onconnect, onmessage);
    console.log("sending join game");
    // Rejoin game from the start so we don't miss any turns.
    this.transport.rejoinGame(0);
  }

  public stop() {
    this.soundManager.dispose();
    this.graphicsListenerAbort?.abort();
    // Detach the input handler's window/canvas listeners and its EventBus
    // subscription. Nothing else ever did, and the bus is created once per
    // page, so a handler from a finished game kept translating keys into
    // events that the next game receives, and joining another game without a
    // page reload stacked a second live handler on top. Idempotent, like the
    // disposals around it.
    this.input.destroy();
    this.disposeRenderer?.();
    if (!this.isActive) return;

    this.isActive = false;
    this.metrics?.stop();
    this.worker.cleanup();
    this.transport.leaveGame();
    if (this.connectionCheckInterval) {
      clearInterval(this.connectionCheckInterval);
      this.connectionCheckInterval = null;
    }
    if (this.goToPlayerTimeout) {
      clearTimeout(this.goToPlayerTimeout);
      this.goToPlayerTimeout = null;
    }
  }

  /** 개선 9: true while the delegation panel waits for a zone-pick click. */
  private delegationZonePick = false;

  private inputEvent(event: MouseUpEvent) {
    if (!this.isActive || this.renderer.uiState.ghostStructure !== null) {
      return;
    }
    const cell = this.renderer.transformHandler.screenToWorldCoordinates(
      event.x,
      event.y,
    );
    if (!this.gameView.isValidCoord(cell.x, cell.y)) {
      return;
    }
    console.log(`clicked cell ${cell}`);
    const tile = this.gameView.ref(cell.x, cell.y);
    if (
      this.gameView.isLand(tile) &&
      !this.gameView.hasOwner(tile) &&
      this.gameView.inSpawnPhase() &&
      !this.gameView.config().isRandomSpawn()
    ) {
      this.eventBus.emit(new SendSpawnIntentEvent(tile));
      return;
    }
    if (this.gameView.inSpawnPhase()) {
      return;
    }
    if (this.delegationZonePick) {
      this.delegationZonePick = false;
      this.eventBus.emit(new DelegationZonePickedEvent(tile));
      return;
    }
    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }
    this.myPlayer
      .actions(tile, [UnitType.TransportShip])
      .then((actions) => {
        if (actions.canAttack) {
          // 개선 7: while paused the LocalServer would drop this intent, so
          // queue it as a plan order instead (neutral land -> null target).
          if (this.shouldQueuePlanOrder()) {
            this.eventBus.emit(
              new QueuePlanOrderEvent(
                "attack",
                this.gameView.owner(tile).id(),
                tile,
                clampPlanRatio(this.renderer.uiState.attackRatio * 100),
              ),
            );
            return;
          }
          this.eventBus.emit(
            new SendAttackIntentEvent(
              this.gameView.owner(tile).id(),
              this.myPlayer!.troops() * this.renderer.uiState.attackRatio,
            ),
          );
        } else if (this.canAutoBoat(actions.buildableUnits, tile)) {
          this.sendBoatAttackIntent(tile);
        }
      })
      .catch((error) => {
        console.warn("Failed to check boat attack actions:", error);
      });
  }

  private autoUpgradeEvent(event: AutoUpgradeEvent) {
    if (!this.isActive) {
      return;
    }

    const cell = this.renderer.transformHandler.screenToWorldCoordinates(
      event.x,
      event.y,
    );
    if (!this.gameView.isValidCoord(cell.x, cell.y)) {
      return;
    }

    const tile = this.gameView.ref(cell.x, cell.y);

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    if (this.gameView.inSpawnPhase()) {
      return;
    }

    this.findAndUpgradeNearestBuilding(tile);
  }

  private findAndUpgradeNearestBuilding(clickedTile: TileRef) {
    this.myPlayer!.actions(clickedTile, Structures.types)
      .then((actions) => {
        const upgradeUnits: {
          unitId: number;
          unitType: UnitType;
          distance: number;
        }[] = [];

        for (const bu of actions.buildableUnits) {
          if (bu.canUpgrade !== false) {
            const existingUnit = this.gameView
              .units()
              .find((unit) => unit.id() === bu.canUpgrade);
            if (existingUnit) {
              const distance = this.gameView.manhattanDist(
                clickedTile,
                existingUnit.tile(),
              );

              upgradeUnits.push({
                unitId: bu.canUpgrade,
                unitType: bu.type,
                distance: distance,
              });
            }
          }
        }

        if (upgradeUnits.length === 0) {
          return;
        }

        // Upgrade the closest affordable building. But if there's an unaffordable
        // building (any type) that's closer to clickedTile than the best candidate,
        // do nothing — the player clicked on that unaffordable building intending
        // to upgrade it, and we must not spend their gold on a different building.
        const bestUpgrade = findClosestBy(upgradeUnits, (u) => u.distance);
        if (!bestUpgrade) {
          return;
        }

        // Check if any unaffordable building is closer than bestUpgrade
        for (const bu of actions.buildableUnits) {
          if (bu.canUpgrade === false && bu.type !== bestUpgrade.unitType) {
            const myPlayerID = this.myPlayer!.id();
            const closestOfType = this.gameView
              .nearbyUnits(
                clickedTile,
                this.gameView.config().structureMinDist(),
                bu.type,
              )
              .filter(({ unit }) => unit.owner().id() === myPlayerID)
              .sort((a, b) => a.distSquared - b.distSquared)[0];

            if (closestOfType) {
              const dist = this.gameView.manhattanDist(
                clickedTile,
                closestOfType.unit.tile(),
              );
              if (dist <= bestUpgrade.distance) {
                // An unaffordable building of type bu.type is at least as close
                // as bestUpgrade — player clicked on it, not on bestUpgrade.
                return;
              }
            }
          }
        }

        this.eventBus.emit(
          new SendUpgradeStructureIntentEvent(
            bestUpgrade.unitId,
            bestUpgrade.unitType,
          ),
        );
      })
      .catch((error) => {
        console.warn("Failed to check structure upgrade actions:", error);
      });
  }

  private doBoatAttackUnderCursor(e: DoBoatAttackEvent): void {
    const tile = this.actionTile(e.tile);
    if (tile === null) {
      return;
    }

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    this.myPlayer
      .buildables(tile, [UnitType.TransportShip])
      .then((buildables) => {
        if (this.canBoatAttack(buildables) !== false) {
          this.sendBoatAttackIntent(tile);
        } else {
          console.warn(
            "Boat attack triggered but can't send Transport Ship to tile",
          );
        }
      })
      .catch((error) => {
        console.warn("Failed to check boat attack actions:", error);
      });
  }

  private doGroundAttackUnderCursor(): void {
    const tile = this.getTileUnderCursor();
    if (tile === null) {
      return;
    }

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    this.myPlayer
      .actions(tile, null)
      .then((actions) => {
        if (actions.canAttack) {
          this.eventBus.emit(
            new SendAttackIntentEvent(
              this.gameView.owner(tile).id(),
              this.myPlayer!.troops() * this.renderer.uiState.attackRatio,
            ),
          );
        }
      })
      .catch((error) => {
        console.warn("Failed to check ground attack actions:", error);
      });
  }

  private doRetaliateAttackMostRecent(): void {
    if (!this.isActive || this.gameView.inSpawnPhase()) {
      return;
    }

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    const incomingAttacks = this.myPlayer.incomingAttacks().filter((a) => {
      const t = (
        this.gameView.playerBySmallID(a.attackerID) as PlayerView
      ).type();
      return t !== PlayerType.Bot;
    });

    if (incomingAttacks.length === 0) return;

    const mostRecentAttack = incomingAttacks[incomingAttacks.length - 1];

    const attacker = this.gameView.playerBySmallID(
      mostRecentAttack.attackerID,
    ) as PlayerView;
    if (!attacker) return;

    const counterTroops = counterAttackTroops(
      mostRecentAttack.troops,
      this.renderer.uiState.attackRatio * this.myPlayer.troops(),
    );
    this.eventBus.emit(new SendAttackIntentEvent(attacker.id(), counterTroops));
  }

  private doRequestAllianceUnderCursor(e: DoRequestAllianceEvent): void {
    const tile = this.actionTile(e.tile);
    if (tile === null) return;

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    const myPlayer = this.myPlayer;

    const tileOwner = this.gameView.owner(tile);
    if (!tileOwner.isPlayer()) return;
    if (e.playerID !== undefined && tileOwner.id() !== e.playerID) return;
    const recipient = tileOwner as PlayerView;

    myPlayer
      .actions(tile)
      .then((actions) => {
        if (actions.interaction?.canSendAllianceRequest) {
          this.eventBus.emit(
            new SendAllianceRequestIntentEvent(myPlayer, recipient),
          );
        } else if (actions.interaction?.allianceInfo?.canExtend) {
          this.eventBus.emit(new SendAllianceExtensionIntentEvent(recipient));
        }
      })
      .catch((error) => {
        console.warn("Failed to check alliance actions:", error);
      });
  }

  private doBreakAllianceUnderCursor(e: DoBreakAllianceEvent): void {
    const tile = this.actionTile(e.tile);
    if (tile === null) return;

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    const myPlayer = this.myPlayer;

    const tileOwner = this.gameView.owner(tile);
    if (!tileOwner.isPlayer()) return;
    if (e.playerID !== undefined && tileOwner.id() !== e.playerID) return;
    const recipient = tileOwner as PlayerView;

    myPlayer
      .actions(tile)
      .then((actions) => {
        if (actions.interaction?.canBreakAlliance) {
          this.eventBus.emit(
            new SendBreakAllianceIntentEvent(myPlayer, recipient),
          );
        }
      })
      .catch((error) => {
        console.warn("Failed to check alliance actions:", error);
      });
  }

  private doTargetPlayerUnderCursor(e: DoTargetPlayerEvent): void {
    const tile = this.actionTile(e.tile);
    if (tile === null) return;

    if (this.myPlayer === null) {
      if (!this.clientID) return;
      const myPlayer = this.gameView.playerByClientID(this.clientID);
      if (myPlayer === null) return;
      this.myPlayer = myPlayer;
    }

    const tileOwner = this.gameView.owner(tile);
    if (!tileOwner.isPlayer()) return;
    if (e.playerID !== undefined && tileOwner.id() !== e.playerID) return;
    const target = tileOwner as PlayerView;

    this.myPlayer
      .actions(tile)
      .then((actions) => {
        if (actions.interaction?.canTarget) {
          this.eventBus.emit(new SendTargetPlayerIntentEvent(target.id()));
        }
      })
      .catch((error) => {
        console.warn("Failed to check target actions:", error);
      });
  }

  // The tile a player action event names (a panel button), or else the one
  // under the cursor (a keybind).
  private actionTile(tile: TileRef | undefined): TileRef | null {
    if (tile === undefined) return this.getTileUnderCursor();
    if (!this.isActive || this.gameView.inSpawnPhase()) return null;
    return tile;
  }

  private getTileUnderCursor(): TileRef | null {
    if (!this.isActive || !this.lastMousePosition) {
      return null;
    }
    if (this.gameView.inSpawnPhase()) {
      return null;
    }
    const cell = this.renderer.transformHandler.screenToWorldCoordinates(
      this.lastMousePosition.x,
      this.lastMousePosition.y,
    );
    if (!this.gameView.isValidCoord(cell.x, cell.y)) {
      return null;
    }
    return this.gameView.ref(cell.x, cell.y);
  }

  private canBoatAttack(buildables: BuildableUnit[]): false | TileRef {
    const bu = buildables.find((bu) => bu.type === UnitType.TransportShip);
    return bu?.canBuild ?? false;
  }

  private shouldQueuePlanOrder(): boolean {
    if (!this.renderer.uiState.paused) return false;
    if (
      this.gameView.config().gameConfig().gameType !== GameType.Singleplayer
    ) {
      return false;
    }
    if (this.gameView.config().isReplay()) return false;
    if (this.gameView.inSpawnPhase()) return false;
    return true;
  }

  private sendBoatAttackIntent(tile: TileRef) {
    if (!this.myPlayer) return;

    // 개선 7: queue the boat attack as a plan order while paused.
    if (this.shouldQueuePlanOrder()) {
      this.eventBus.emit(
        new QueuePlanOrderEvent(
          "boat",
          null,
          tile,
          clampPlanRatio(this.renderer.uiState.attackRatio * 100),
        ),
      );
      return;
    }

    this.eventBus.emit(
      new SendBoatAttackIntentEvent(
        tile,
        this.myPlayer.troops() * this.renderer.uiState.attackRatio,
      ),
    );
  }

  private canAutoBoat(buildables: BuildableUnit[], tile: TileRef): boolean {
    if (!this.gameView.isLand(tile)) return false;

    const canBuild = this.canBoatAttack(buildables);
    if (canBuild === false) return false;

    // TODO: honor a global auto-boat enable flag once it exists.
    // if (!this.userSettings.autoBoat()) return false;
    // TODO: honor a global "limit auto-boat to nearby shore" flag once it exists.
    // if (!this.userSettings.autoBoatNearbyOnly()) return true;
    const distanceSquared = this.gameView.euclideanDistSquared(tile, canBuild);
    const limit = 100;
    const limitSquared = limit * limit;
    return distanceSquared < limitSquared;
  }

  private onMouseMove(event: MouseMoveEvent) {
    this.lastMousePosition = { x: event.x, y: event.y };
  }

  private onConnectionCheck() {
    if (this.transport.isLocal) {
      return;
    }
    const now = Date.now();
    const timeSinceLastMessage = now - this.lastMessageTime;
    if (timeSinceLastMessage > 5000) {
      console.log(
        `No message from server for ${timeSinceLastMessage} ms, reconnecting`,
      );
      this.lastMessageTime = now;
      this.transport.reconnect();
    }
  }
}

function showErrorModal(
  error: string,
  message: string | undefined,
  gameID: GameID,
  clientID: ClientID | undefined,
  closable = false,
  showDiscord = true,
  heading = "error_modal.crashed",
) {
  if (document.querySelector("#error-modal")) {
    return;
  }

  reportGameError(error, message, gameID, clientID, heading);

  const translatedError = translateText(error);
  const displayError = translatedError === error ? error : translatedError;

  const modal = document.createElement("div");
  modal.id = "error-modal";

  const content = [
    showDiscord ? translateText("error_modal.paste_discord") : null,
    translateText(heading),
    `game id: ${gameID}`,
    `client id: ${clientID}`,
    `Error: ${displayError}`,
    message ? `Message: ${message}` : null,
  ]
    .filter(Boolean)
    .join("\n");

  // Create elements
  const pre = document.createElement("pre");
  pre.textContent = content;

  const button = document.createElement("button");
  button.textContent = translateText("error_modal.copy_clipboard");
  button.className = "copy-btn";
  button.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(content);
      button.textContent = translateText("common.copied");
    } catch {
      button.textContent = translateText("common.failed_copy");
    }
  });

  // Add to modal
  modal.appendChild(pre);
  modal.appendChild(button);
  if (closable) {
    const closeButton = document.createElement("button");
    closeButton.textContent = "X";
    closeButton.className = "close-btn";
    closeButton.addEventListener("click", () => {
      modal.remove();
    });
    modal.appendChild(closeButton);
  }

  document.body.appendChild(modal);
}
