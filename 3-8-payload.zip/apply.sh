#!/bin/bash
# 개선 7 일시정지 작전 계획 (v2: 기본 클릭 공격 경로 포함)
set -e
cp -r /tmp/payload/files/. .
echo "applied $(find /tmp/payload/files -type f | wc -l) files"
