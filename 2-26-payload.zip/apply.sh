#!/bin/sh
cp -r /tmp/payload/files/. .
