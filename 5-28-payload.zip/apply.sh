set -e
cp /tmp/payload/resources/lang/en.json /tmp/payload/resources/lang/ko.json resources/lang/
cp /tmp/payload/src/client/hud/layers/DelegationPanel.ts src/client/hud/layers/
cp /tmp/payload/docs/DESIGN.md docs/
rm -f *payload.zip
