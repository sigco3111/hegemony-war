#!/usr/bin/env bash
set -euo pipefail
root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cp "$root/README.md" README.md
mkdir -p docs/screenshots
cp "$root/screenshots/"*.webp docs/screenshots/
