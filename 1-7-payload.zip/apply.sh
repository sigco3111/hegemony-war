#!/bin/bash
# 개선 7 일시정지 작전 계획: overlay the payload file tree onto the repo root.
set -e
cp -r /tmp/payload/files/. .
echo "applied $(find /tmp/payload/files -type f | wc -l) files"
